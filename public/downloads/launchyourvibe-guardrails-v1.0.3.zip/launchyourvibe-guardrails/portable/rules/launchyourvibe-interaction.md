# LaunchYourVibe — Interaction

Optional Interaction rules from LaunchYourVibe. Enable this rule when working in this domain.

### I-01 — Every Button Needs 4 States. Minimum.

**When:** Working on every button needs 4 states. minimum. (Interaction)

**Rule:** **Missing a state isn't neutral.** No disabled state feels broken when nothing happens. Each state signals what's possible right now.

**Reference:** https://launchyourvibe.live/card/i-01

### I-02 — Error Messages: Say What + Why + Fix

**When:** Designing click/tap targets, buttons, or touch-friendly controls

**Rule:** **What happened. Why. What to do.** Three sentences max. Plain language. No stack traces. Never blame the user.

**Reference:** https://launchyourvibe.live/card/i-02

### I-03 — Loading: Match the Wait to the Pattern

**When:** Loading data, fetching content, or waiting on async operations

**Rule:** **Blank screens feel broken; spinners feel slow.** Use skeleton loaders for content-heavy loads. Spinners for <2s actions. Progress bars when the user needs to know how long.

**Reference:** https://launchyourvibe.live/card/i-03

### I-04 — Destructive Actions Need Friction: On Purpose

**When:** Working on destructive actions need friction: on purpose (Interaction)

**Rule:** **Make the danger legible.** Red button, explicit label, and a cost statement. "Are you sure?" without consequences doesn't create real friction: specifics do.

**Reference:** https://launchyourvibe.live/card/i-04

### I-05 — Success Is a Moment. Mark It.

**When:** Working on success is a moment. mark it. (Interaction)

**Rule:** **Silence after a successful action breeds doubt.** Confirm what happened, to whom, and what comes next. The user's mental model needs closure.

**Reference:** https://launchyourvibe.live/card/i-05

### I-06 — Toast = Info. Dialog = Decision.

**When:** Working on toast = info. dialog = decision. (Interaction)

**Rule:** **Dialogs steal focus because they have to.** If the user can ignore it, use a toast. If they must choose, use a dialog. Never use a dialog to say something they don't need to act on.

**Reference:** https://launchyourvibe.live/card/i-06

### I-07 — Validate on Blur, Not on Keystroke

**When:** Working on validate on blur, not on keystroke (Interaction)

**Rule:** **Showing errors while someone is mid-thought is hostile.** Wait for blur (field exit) to validate. Only re-validate on keystroke after the first error appears. Never on every character.

**Reference:** https://launchyourvibe.live/card/i-07

### I-08 — Optimistic UI: Show Success First

**When:** Working on optimistic ui: show success first (Interaction)

**Rule:** **Most requests succeed.** Assume success, update the UI immediately, sync in the background. Roll back only on actual failure. The app feels instant even when it isn't.

**Reference:** https://launchyourvibe.live/card/i-08

### I-09 — Undo Beats Confirm Dialogs

**When:** Working on undo beats confirm dialogs (Interaction)

**Rule:** **Confirms interrupt flow. Undo restores agency.** Let users act immediately, then give them a short window to reverse it. They feel more in control, not less.

**Reference:** https://launchyourvibe.live/card/i-09

### I-10 — Every Tap Needs Immediate Feedback

**When:** Working on every tap needs immediate feedback (Interaction)

**Rule:** **Without feedback, users tap twice.** Response within 100ms feels instantaneous. 100–300ms feels fast. Beyond 300ms, users start to doubt. Give visual feedback first, everything else second.

**Reference:** https://launchyourvibe.live/card/i-10

### I-11 — Progress: Show Where They Are

**When:** Working on progress: show where they are (Interaction)

**Rule:** **Progress without context is just anxiety.** Show step number, percentage, or time estimate. Giving users a frame of reference reduces perceived wait time by 40%.

**Reference:** https://launchyourvibe.live/card/i-11

### I-12 — Hover Actions Don't Exist on Mobile

**When:** Adding hover-only actions, tooltips, or menus that reveal on pointer hover

**Rule:** **Touch has no cursor.** Any interaction hidden behind hover is invisible on mobile. If your content needs additional actions, make them visible, not discoverable via pointer proximity.

**Reference:** https://launchyourvibe.live/card/i-12

### I-13 — Disabled Means "Not Yet": Explain Why

**When:** Working on disabled means "not yet": explain why (Interaction)

**Rule:** **A grayed button with no explanation creates confusion.** Tell users what they're missing. The block becomes a guide, and prevents them from abandoning the form in frustration.

**Reference:** https://launchyourvibe.live/card/i-13

### I-14 — Swipe Actions Need Visual Teaching

**When:** Working on swipe actions need visual teaching (Interaction)

**Rule:** **Gestures are invisible until taught.** On first use, animate a partial swipe. Use destructive actions only on one side: left for danger is a convention users already know.

**Reference:** https://launchyourvibe.live/card/i-14

### I-15 — Right Keyboard for Every Input

**When:** Adding phone, email, number, or other typed input fields

**Rule:** **The wrong keyboard is a tiny betrayal of trust.** A number pad for phone numbers, @ key for emails: set inputmode or type correctly and the keyboard is already optimized.

**Reference:** https://launchyourvibe.live/card/i-15

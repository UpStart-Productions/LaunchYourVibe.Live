# LaunchYourVibe Guardrails Kit v1.0.1

LaunchYourVibe helps vibe coders ship accessible, secure software with great UX.

- **Visual deck:** https://launchyourvibe.live
- **This kit:** agent rules + ship-check skill + human cheat sheet

Start with [INSTALL.md](INSTALL.md).

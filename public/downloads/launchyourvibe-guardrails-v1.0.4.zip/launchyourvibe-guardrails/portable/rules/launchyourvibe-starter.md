# LaunchYourVibe Starter Guardrails

LaunchYourVibe starter guardrails — always-on rules for vibe coders who ship with AI.

Apply these proactively while generating UI, forms, auth, and data-handling code.

Before marking work complete, offer to run the **LaunchYourVibe ship check** skill (see `cursor/skills/launchyourvibe-ship-check/`).

### A-04 — Every Interactive Element Needs a Label

**When:** Creating icon-only buttons or controls with no visible text label

**Rule:** **Icon buttons are invisible to screen readers without labels.** Add `aria-label` to every icon-only button. Use `aria-labelledby` when a visible label exists nearby. The label should describe the action, not the icon.

**Reference:** https://launchyourvibe.live/card/a-04

### A-09 — Labels Always Visible: Never Placeholder-Only

**When:** Adding form inputs, search fields, or any text field

**Rule:** **Placeholders vanish when users start typing.** This breaks cognitive load for anyone who forgets what a field was, and breaks screen readers entirely. Use a persistent `<label>` element for every input. Placeholder text is fine for examples: not for labels.

**Reference:** https://launchyourvibe.live/card/a-09

### A-10 — Link Errors to Their Fields Programmatically

**When:** Showing validation errors, helper text, or inline field feedback

**Rule:** **Screen readers don't infer visual proximity.** Use `aria-describedby` to link the error message to its input, and `role="alert"` so it's announced immediately when it appears. `aria-invalid="true"` also signals the field state.

**Reference:** https://launchyourvibe.live/card/a-10

### A-14 — Icon Buttons Need Accessible Names

**When:** Naming interactive elements for screen readers (buttons, links, inputs)

**Rule:** **The accessible name is what screen readers announce.** For icon-only buttons the visual label is the icon: which is meaningless to AT. Pick the strategy that fits: `aria-label` for standalone icons, visually-hidden text when you need translatable strings, `aria-labelledby` when a visible label exists nearby.

**Reference:** https://launchyourvibe.live/card/a-14

### A-05 — Semantic HTML: Structure Is Meaning

**When:** Choosing HTML elements (buttons, links, headings, landmarks) for structure

**Rule:** **HTML elements carry meaning that assistive tech relies on.** Use `<button>` for actions, `<a>` for navigation, and heading tags in sequential order. Screen readers use landmark elements (`main`, `nav`, `aside`) to let users jump between page sections.

**Reference:** https://launchyourvibe.live/card/a-05

### I-03 — Loading: Match the Wait to the Pattern

**When:** Loading data, fetching content, or waiting on async operations

**Rule:** **Blank screens feel broken; spinners feel slow.** Use skeleton loaders for content-heavy loads. Spinners for <2s actions. Progress bars when the user needs to know how long.

**Reference:** https://launchyourvibe.live/card/i-03

### I-12 — Hover Actions Don't Exist on Mobile

**When:** Adding hover-only actions, tooltips, or menus that reveal on pointer hover

**Rule:** **Touch has no cursor.** Any interaction hidden behind hover is invisible on mobile. If your content needs additional actions, make them visible, not discoverable via pointer proximity.

**Reference:** https://launchyourvibe.live/card/i-12

### I-15 — Right Keyboard for Every Input

**When:** Adding phone, email, number, or other typed input fields

**Rule:** **The wrong keyboard is a tiny betrayal of trust.** A number pad for phone numbers, @ key for emails: set inputmode or type correctly and the keyboard is already optimized.

**Reference:** https://launchyourvibe.live/card/i-15

### I-02 — Error Messages: Say What + Why + Fix

**When:** Designing click/tap targets, buttons, or touch-friendly controls

**Rule:** **What happened. Why. What to do.** Three sentences max. Plain language. No stack traces. Never blame the user.

**Reference:** https://launchyourvibe.live/card/i-02

### N-01 — Empty States Are Not Optional

**When:** Rendering empty lists, dashboards, inboxes, or zero-result states

**Rule:** **Every empty screen is a first impression of a feature.** Tell them what belongs here, why it's empty, and exactly what to do next. Icon + headline + CTA. Three elements, every time.

**Reference:** https://launchyourvibe.live/card/n-01

### N-02 — New Screen or Overlay? Ask About Context.

**When:** Choosing between a modal/dialog and a new page or route

**Rule:** **The choice is really about whether the user is leaving their current task or pausing it.** If they're leaving, push a new screen. If they're pausing, use an overlay that lets them see and return to where they came from.

**Reference:** https://launchyourvibe.live/card/n-02

### C-11 — 4 Alert Levels. Don't Cry Wolf.

**When:** Showing alerts, banners, toasts, or status messages

**Rule:** **Every alert in red trains users to ignore red.** Reserve error alerts for actual errors. Info banners for context. If everything is urgent, nothing is. Overused alerts become wallpaper.

**Reference:** https://launchyourvibe.live/card/c-11

### C-14 — Tooltips Are for Desktop Power Users

**When:** Relying on tooltips to explain how a control works

**Rule:** **If users need a tooltip to use a feature, the feature needs better labeling.** Tooltips are bonus context for experienced users: not a substitute for clear UI copy. And they don't exist on touch screens.

**Reference:** https://launchyourvibe.live/card/c-14

### C-01 — Modal → Desktop Bottom Sheet → Mobile

**When:** Building primary/secondary actions or button hierarchies

**Rule:** **Modals trap thumbs.** On mobile, a centered dialog requires two-handed use. A bottom sheet rises from where thumbs already live. Same intent. Opposite ergonomics.

**Reference:** https://launchyourvibe.live/card/c-01

### S-01 — Filter by User ID. Always.

**When:** Handling authentication, login, or session management

**Rule:** **Every user-specific fetch must filter by the authenticated user's ID.** Test it by logging in as User A and manually requesting User B's data. If you can see it, you have a problem. This isn't a platform feature you toggle on — it's a check you write and verify.

**Reference:** https://launchyourvibe.live/card/s-01

### S-02 — Use Supabase, Clerk, or Auth0.

**When:** Storing secrets, API keys, or credentials in code or config

**Rule:** **Rolling your own session management is where breaches are born.** Use Supabase Auth, Clerk, or Auth0. They handle tokens, refresh, MFA, and OAuth so you don't have to — and they stay patched when new vulnerabilities emerge.

**Reference:** https://launchyourvibe.live/card/s-02

### S-03 — Hiding a Button Is Not Security.

**When:** Protecting routes, APIs, admin actions, or sensitive data

**Rule:** **Every protected action checks the session on the server before returning data.** UI-only access control is theater — a crafted request bypasses it in seconds. Hiding a button is not access control.

**Reference:** https://launchyourvibe.live/card/s-03

### S-07 — localStorage = Readable by Any Script.

**When:** Persisting auth tokens (JWT, session) in the browser

**Rule:** **JWTs stored in localStorage are readable by any script on the page.** httpOnly cookies are not. One XSS vulnerability with localStorage tokens = full account takeover.

**Reference:** https://launchyourvibe.live/card/s-07

### S-10 — User Content Is Untrusted HTML.

**When:** Rendering user-generated or untrusted HTML/content

**Rule:** **User-generated content rendered directly to the DOM is an XSS vector.** Escape or sanitize everything that came from a user before it touches the page.

**Reference:** https://launchyourvibe.live/card/s-10

### P-01 — Every Field Needs a Reason.

**When:** Designing forms, schemas, or data collection flows

**Rule:** **Data you never collected can't leak.** Every field in your schema should have a documented reason to exist. If you can't explain why you need it, don't collect it.

**Reference:** https://launchyourvibe.live/card/p-01

### P-03 — Pre-Checked Isn't Consent.

**When:** Email signup, newsletters, or marketing opt-in flows

**Rule:** **Email requires explicit opt-in.** Pre-checked boxes aren't consent. CAN-SPAM and GDPR both have teeth and neither cares that you're small.

**Reference:** https://launchyourvibe.live/card/p-03

### P-08 — Never Plain Text in a Column.

**When:** Storing passwords, tokens, or PII in a database

**Rule:** **Sensitive fields get encrypted or hashed at rest.** Passwords, tokens, anything personally identifiable — hashed or encrypted at rest. Never plain text in a column.

**Reference:** https://launchyourvibe.live/card/p-08

### P-12 — Drop Unused Fields Before Launch.

**When:** Planning database columns, user profiles, or analytics fields

**Rule:** **Store the least data you can.** Drop unused fields before launch, not after a breach. Data minimization is a design decision, not a cleanup task.

**Reference:** https://launchyourvibe.live/card/p-12

### D-04 — Axis Labels and Units Must Always Be Visible

**When:** Building charts or graphs with axes

**Rule:** **A chart without axis labels is a Rorschach test.** Every axis needs a label and a unit. "Revenue" without "$" or "K" forces users to guess the scale. Never rely on tooltips alone: they're invisible on mobile and require interaction to reveal basic context.

**Reference:** https://launchyourvibe.live/card/d-04

### D-07 — Tables for Lookup. Charts for Patterns.

**When:** Choosing between a chart and a table for numeric data

**Rule:** **Charts reveal patterns; tables reveal values.** If a user needs to look up a specific number, a table serves them better than a chart. If they need to understand a trend, distribution, or comparison across categories, a chart does what a table can't.

**Reference:** https://launchyourvibe.live/card/d-07

### T-02 — The 8pt Grid: Spacing in rem

**When:** Setting spacing, margins, padding, or layout gaps

**Rule:** **Arbitrary spacing makes screens feel unsteady.** Snap component gaps and padding to rem (0.25rem steps on an 8pt grid). For page-level breathing room, use vw in clamp() so gutters grow with the viewport.

**Reference:** https://launchyourvibe.live/card/t-02

### T-14 — Safe Zones: Respect the Hardware

**When:** Building mobile layouts or full-bleed UI near device edges

**Rule:** **UI placed in the notch or behind the home indicator isn't just ugly: it's unusable.** Use CSS env() safe-area variables so your layout always respects the device's hardware edges.

**Reference:** https://launchyourvibe.live/card/t-14

### T-06 — Padding vs Margin: Inside vs Outside

**When:** Deciding between padding and margin on components

**Rule:** **Padding changes the element's feel; margin changes its relationship to neighbors.** Use padding to make a button feel spacious. Use margin to create breathing room in a layout.

**Reference:** https://launchyourvibe.live/card/t-06

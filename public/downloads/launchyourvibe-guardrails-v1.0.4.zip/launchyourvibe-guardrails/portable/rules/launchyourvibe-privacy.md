# LaunchYourVibe — Privacy

Optional Privacy rules from LaunchYourVibe. Enable this rule when working in this domain.

### P-01 — Every Field Needs a Reason.

**When:** Designing forms, schemas, or data collection flows

**Rule:** **Data you never collected can't leak.** Every field in your schema should have a documented reason to exist. If you can't explain why you need it, don't collect it.

**Reference:** https://launchyourvibe.live/card/p-01

### P-02 — Policy = What You Actually Collect.

**When:** Working on policy = what you actually collect. (Privacy)

**Rule:** **Your privacy policy must match the code, not your intentions.** It describes what you actually collect, not what you intended to. A lying policy is legally worse than none.

**Reference:** https://launchyourvibe.live/card/p-02

### P-03 — Pre-Checked Isn't Consent.

**When:** Email signup, newsletters, or marketing opt-in flows

**Rule:** **Email requires explicit opt-in.** Pre-checked boxes aren't consent. CAN-SPAM and GDPR both have teeth and neither cares that you're small.

**Reference:** https://launchyourvibe.live/card/p-03

### P-04 — Know Where Every Piece Lives.

**When:** Working on know where every piece lives. (Privacy)

**Rule:** **Users can delete their data — you need to know where it all is first.** Know where every piece of user data lives before someone asks you to remove it. "I'm not sure" is not an answer.

**Reference:** https://launchyourvibe.live/card/p-04

### P-05 — Logs Are a Liability Too.

**When:** Working on logs are a liability too. (Privacy)

**Rule:** **Don't log what you don't need.** Full user-agents, IP addresses, raw request bodies — if you're not actively using it, don't keep it. Logs are a liability too.

**Reference:** https://launchyourvibe.live/card/p-05

### P-06 — Know What You've Invited In.

**When:** Working on know what you've invited in. (Privacy)

**Rule:** **Third-party scripts see everything on your page.** Every analytics tag, chat widget, and ad pixel has access to your DOM and potentially your users' data. Know what you've invited in.

**Reference:** https://launchyourvibe.live/card/p-06

### P-07 — Stolen Credentials Shouldn't Last Forever.

**When:** Working on stolen credentials shouldn't last forever. (Privacy)

**Rule:** **Sessions that never expire are stolen credentials that work forever.** Set a reasonable timeout and enforce it. Refresh tokens rotate; idle sessions die.

**Reference:** https://launchyourvibe.live/card/p-07

### P-08 — Never Plain Text in a Column.

**When:** Storing passwords, tokens, or PII in a database

**Rule:** **Sensitive fields get encrypted or hashed at rest.** Passwords, tokens, anything personally identifiable — hashed or encrypted at rest. Never plain text in a column.

**Reference:** https://launchyourvibe.live/card/p-08

### P-09 — A Backup You've Never Restored Is a Guess.

**When:** Working on a backup you've never restored is a guess. (Privacy)

**Rule:** **Backups exist and are tested.** Know where your backups are and verify one actually works. A backup you've never restored is a guess.

**Reference:** https://launchyourvibe.live/card/p-09

### P-10 — Treat Every Repo As Public Tomorrow.

**When:** Working on treat every repo as public tomorrow. (Privacy)

**Rule:** **Private repos aren't security.** Treat every repo as if it could go public tomorrow. Private today doesn't mean private forever — misconfigured permissions, acquired companies, and leaked tokens happen.

**Reference:** https://launchyourvibe.live/card/p-10

### P-11 — No DROP or ALTER for Your App User.

**When:** Working on no drop or alter for your app user. (Privacy)

**Rule:** **Least privilege on database users.** Your app's database user shouldn't have DROP or ALTER permissions. Give it only what it needs to function — SELECT, INSERT, UPDATE, DELETE on specific tables.

**Reference:** https://launchyourvibe.live/card/p-11

### P-12 — Drop Unused Fields Before Launch.

**When:** Planning database columns, user profiles, or analytics fields

**Rule:** **Store the least data you can.** Drop unused fields before launch, not after a breach. Data minimization is a design decision, not a cleanup task.

**Reference:** https://launchyourvibe.live/card/p-12

### P-13 — Third Parties Belong in Your Policy.

**When:** Working on third parties belong in your policy. (Privacy)

**Rule:** **Disclose what you share.** If data touches a third party — analytics, payment processor, email provider — your privacy policy says so explicitly. Name them, name the data, name the purpose.

**Reference:** https://launchyourvibe.live/card/p-13

### P-14 — Export, Correct, and Delete.

**When:** Working on export, correct, and delete. (Privacy)

**Rule:** **Give users control over their data.** Export, correction, and deletion aren't just legal requirements in some jurisdictions. They're what trustworthy products do.

**Reference:** https://launchyourvibe.live/card/p-14

### P-15 — Know Who to Notify Before It Happens.

**When:** Working on know who to notify before it happens. (Privacy)

**Rule:** **Breach plan before you need one.** Know who you'd notify, in what order, within what timeframe. Figuring it out during an incident is too late.

**Reference:** https://launchyourvibe.live/card/p-15

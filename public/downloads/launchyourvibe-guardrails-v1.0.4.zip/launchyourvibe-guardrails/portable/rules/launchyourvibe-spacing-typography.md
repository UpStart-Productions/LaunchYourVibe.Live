# LaunchYourVibe — Spacing & Typography

Optional Spacing & Typography rules from LaunchYourVibe. Enable this rule when working in this domain.

### T-01 — Fluid Type: rem + clamp()

**When:** Working on fluid type: rem + clamp() (Spacing & Typography)

**Rule:** **Px breakpoints snap; user settings get ignored.** Set type in rem and scale smoothly with clamp(): a minimum rem, a viewport-relative middle term, and a maximum rem. One formula replaces separate mobile and desktop charts.

**Reference:** https://launchyourvibe.live/card/t-01

### T-02 — The 8pt Grid: Spacing in rem

**When:** Setting spacing, margins, padding, or layout gaps

**Rule:** **Arbitrary spacing makes screens feel unsteady.** Snap component gaps and padding to rem (0.25rem steps on an 8pt grid). For page-level breathing room, use vw in clamp() so gutters grow with the viewport.

**Reference:** https://launchyourvibe.live/card/t-02

### T-03 — Line Length: 45–75 Characters

**When:** Working on line length: 45–75 characters (Spacing & Typography)

**Rule:** **Long lines force the eye to hunt for the next line.** Short columns increase jumps per paragraph. 45–75 chars is where reading becomes effortless.

**Reference:** https://launchyourvibe.live/card/t-03

### T-04 — Weight Does the Hierarchy Work

**When:** Working on weight does the hierarchy work (Spacing & Typography)

**Rule:** **Color and size aren't the only tools.** Weight creates hierarchy even in a single color. Use 400 for body, 600 for labels, 700 for headings: avoid everything in between.

**Reference:** https://launchyourvibe.live/card/t-04

### T-05 — Line Height by Text Role

**When:** Working on line height by text role (Spacing & Typography)

**Rule:** **Tight headings look intentional. Tight body text looks like a bug.** Body line-height starts at 1.5 (WCAG). Button height comes from padding, not cramping line-height to 1.0.

**Reference:** https://launchyourvibe.live/card/t-05

### T-06 — Padding vs Margin: Inside vs Outside

**When:** Deciding between padding and margin on components

**Rule:** **Padding changes the element's feel; margin changes its relationship to neighbors.** Use padding to make a button feel spacious. Use margin to create breathing room in a layout.

**Reference:** https://launchyourvibe.live/card/t-06

### T-07 — Visual Hierarchy: 3 Levels Maximum

**When:** Working on visual hierarchy: 3 levels maximum (Spacing & Typography)

**Rule:** **Every level you add competes with the others.** Primary, secondary, and body. That's the hierarchy. Adding a fourth level usually means the third was doing too much.

**Reference:** https://launchyourvibe.live/card/t-07

### T-08 — Whitespace Is a Design Element

**When:** Working on whitespace is a design element (Spacing & Typography)

**Rule:** **Space is not empty: it's structure.** Generous spacing reduces cognitive load. The gaps between elements tell users which things belong together and what's a separate thought.

**Reference:** https://launchyourvibe.live/card/t-08

### T-09 — Left-Align Body Text. Center Sparingly.

**When:** Working on left-align body text. center sparingly. (Spacing & Typography)

**Rule:** **Centered multi-line text is the hallmark of amateur design.** The ragged left edge forces the eye to hunt for the start of each new line. Left-align everything longer than a headline.

**Reference:** https://launchyourvibe.live/card/t-09

### T-10 — Two Font Families. That's the Budget.

**When:** Working on two font families. that's the budget. (Spacing & Typography)

**Rule:** **Example font families in clear roles feel like a system.** Bold and regular are the same family, not a second one. Mixing families without roles creates noise. Three or more feel like you couldn't decide.

**Reference:** https://launchyourvibe.live/card/t-10

### T-12 — Letter Spacing: Where It Helps

**When:** Working on letter spacing: where it helps (Spacing & Typography)

**Rule:** **Tight letter spacing on big type is a design move. Tight spacing on small type is illegible.** The smaller the text, the more spacing it needs: not less. Never tighten body text.

**Reference:** https://launchyourvibe.live/card/t-12

### T-13 — Proximity Creates Visual Grouping

**When:** Working on proximity creates visual grouping (Spacing & Typography)

**Rule:** **A label 8px from its field looks owned. A label 16px away looks like a heading.** The gap between things signals their relationship: closer means "these belong together."

**Reference:** https://launchyourvibe.live/card/t-13

### T-14 — Safe Zones: Respect the Hardware

**When:** Building mobile layouts or full-bleed UI near device edges

**Rule:** **UI placed in the notch or behind the home indicator isn't just ugly: it's unusable.** Use CSS env() safe-area variables so your layout always respects the device's hardware edges.

**Reference:** https://launchyourvibe.live/card/t-14

### T-15 — Color + Type: Two Signals Are Enough

**When:** Working on color + type: two signals are enough (Spacing & Typography)

**Rule:** **Color alone fails for colorblind users.** Pair every color-coded state with a second signal: an icon, label, or shape. This isn't accessibility extra credit; it's baseline UX.

**Reference:** https://launchyourvibe.live/card/t-15

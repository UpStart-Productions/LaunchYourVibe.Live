# LaunchYourVibe — Components

Optional Components rules from LaunchYourVibe. Enable this rule when working in this domain.

### C-01 — Modal → Desktop Bottom Sheet → Mobile

**When:** Building primary/secondary actions or button hierarchies

**Rule:** **Modals trap thumbs.** On mobile, a centered dialog requires two-handed use. A bottom sheet rises from where thumbs already live. Same intent. Opposite ergonomics.

**Reference:** https://launchyourvibe.live/card/c-01

### C-02 — Tab Bar → Mobile Sidebar → Desktop

**When:** Working on tab bar → mobile sidebar → desktop (Components)

**Rule:** **Thumb reach dictates nav placement.** Bottom tabs stay in the natural grip zone on mobile. Sidebars use the screen width that desktop has to spare. Never swap them.

**Reference:** https://launchyourvibe.live/card/c-02

### C-03 — Forms Are Always Single Column on Mobile

**When:** Working on forms are always single column on mobile (Components)

**Rule:** **Two columns on mobile means two columns of tiny inputs.** Users skip fields accidentally and make more errors. Single column, full width. One field, one decision at a time.

**Reference:** https://launchyourvibe.live/card/c-03

### C-04 — Toggle = Immediate. Checkbox = On Submit.

**When:** Working on toggle = immediate. checkbox = on submit. (Components)

**Rule:** **Toggles are instant actions. Checkboxes are selection within a form.** If the setting takes effect the moment you flip it (like dark mode), use a toggle. If it's part of a group submitted together, use checkboxes.

**Reference:** https://launchyourvibe.live/card/c-04

### C-05 — Cards for Browse. Lists for Scan.

**When:** Working on cards for browse. lists for scan. (Components)

**Rule:** **Cards invite exploration; lists support comparison.** Use cards when each item has rich media or requires its own visual weight. Use lists when users are scanning for a specific item quickly.

**Reference:** https://launchyourvibe.live/card/c-05

### C-06 — Dropdowns on Mobile: Use Native or Bottom Sheet

**When:** Working on dropdowns on mobile: use native or bottom sheet (Components)

**Rule:** **Custom dropdowns fight the OS.** Native selects trigger the platform's built-in scroll picker: optimized for touch. Only build custom when the native control genuinely fails the need.

**Reference:** https://launchyourvibe.live/card/c-06

### C-07 — FAB = One Primary Action. One.

**When:** Working on fab = one primary action. one. (Components)

**Rule:** **The FAB is the most prominent tap target on screen.** It implies "this is the thing you do most." If you can't name that one action, the FAB isn't the right pattern.

**Reference:** https://launchyourvibe.live/card/c-07

### C-08 — Chips: Filter or Select, Not Both at Once

**When:** Working on chips: filter or select, not both at once (Components)

**Rule:** **Chips have two distinct jobs: filtering and input.** Don't mix them on the same surface. Filter chips are toggles. Input chips represent values the user has added. Styling should signal the difference.

**Reference:** https://launchyourvibe.live/card/c-08

### C-09 — Accordions Hide Content. Use Them Intentionally.

**When:** Working on accordions hide content. use them intentionally. (Components)

**Rule:** **Accordions create extra work for the user.** Every collapsed section is a barrier. Use them when the content is genuinely optional: not to make a page feel shorter while hiding required reading.

**Reference:** https://launchyourvibe.live/card/c-09

### C-10 — Date Pickers: Match the Date Type

**When:** Working on date pickers: match the date type (Components)

**Rule:** **There is no universal date picker.** Picking a birthday is a different task than scheduling a meeting. The interface should match the cognitive model: not force a calendar view on every date type.

**Reference:** https://launchyourvibe.live/card/c-10

### C-11 — 4 Alert Levels. Don't Cry Wolf.

**When:** Showing alerts, banners, toasts, or status messages

**Rule:** **Every alert in red trains users to ignore red.** Reserve error alerts for actual errors. Info banners for context. If everything is urgent, nothing is. Overused alerts become wallpaper.

**Reference:** https://launchyourvibe.live/card/c-11

### C-12 — Search Placement Signals Its Importance

**When:** Working on search placement signals its importance (Components)

**Rule:** **If search is how most users navigate, it belongs at the top: always visible.** If it's a power-user feature, tuck it in nav. Never make it a modal activation or a tiny corner icon on search-first apps.

**Reference:** https://launchyourvibe.live/card/c-12

### C-13 — Steppers for Small Ranges. Input for Large.

**When:** Working on steppers for small ranges. input for large. (Components)

**Rule:** **Steppers work for small, bounded quantities.** If someone might want 500 of something, don't make them tap 499 times. Offer a direct input. Steppers should cover ranges users reach in under 10 taps.

**Reference:** https://launchyourvibe.live/card/c-13

### C-14 — Tooltips Are for Desktop Power Users

**When:** Relying on tooltips to explain how a control works

**Rule:** **If users need a tooltip to use a feature, the feature needs better labeling.** Tooltips are bonus context for experienced users: not a substitute for clear UI copy. And they don't exist on touch screens.

**Reference:** https://launchyourvibe.live/card/c-14

### C-15 — Infinite Scroll for Browse. Pagination for Find.

**When:** Working on infinite scroll for browse. pagination for find. (Components)

**Rule:** **Infinite scroll removes the user's sense of location.** If they need to return to a specific item or share a result, pagination gives them an address. Endless scroll is for consuming, not finding.

**Reference:** https://launchyourvibe.live/card/c-15

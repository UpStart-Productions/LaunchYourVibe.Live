# LaunchYourVibe — Data

Optional Data rules from LaunchYourVibe. Enable this rule when working in this domain.

### D-01 — Bar = Compare. Line = Change Over Time.

**When:** Working on bar = compare. line = change over time. (Data)

**Rule:** **The wrong chart type doesn't just look off: it misleads.** Use bars when comparing discrete values across categories. Use lines when showing how a single value changes continuously over time. Connecting discrete categories with a line implies continuity that doesn't exist.

**Reference:** https://launchyourvibe.live/card/d-01

### D-02 — Pie Charts: Part-to-Whole Only. Max 5 Slices.

**When:** Working on pie charts: part-to-whole only. max 5 slices. (Data)

**Rule:** **Pie charts only answer one question: what share of the whole?** They require slices to sum to 100%. Beyond 5 slices, human perception breaks down: angles are harder to compare than lengths. Use a bar chart if you want comparison; a pie if you want composition.

**Reference:** https://launchyourvibe.live/card/d-02

### D-03 — Empty Chart States Are Not Optional

**When:** Working on empty chart states are not optional (Data)

**Rule:** **An empty chart with no explanation looks broken.** Design the zero state: explain why there's no data, tell users what action produces data, and consider showing a ghost/preview of what the chart will look like. Every chart needs a zero state, a loading state, and an error state.

**Reference:** https://launchyourvibe.live/card/d-03

### D-04 — Axis Labels and Units Must Always Be Visible

**When:** Building charts or graphs with axes

**Rule:** **A chart without axis labels is a Rorschach test.** Every axis needs a label and a unit. "Revenue" without "$" or "K" forces users to guess the scale. Never rely on tooltips alone: they're invisible on mobile and require interaction to reveal basic context.

**Reference:** https://launchyourvibe.live/card/d-04

### D-05 — Small Multiples Beat One Crowded Chart

**When:** Working on small multiples beat one crowded chart (Data)

**Rule:** **When one chart gets more than 4–5 series, everything competes.** Small multiples repeat the same chart structure for each category, letting users see patterns across dimensions at a glance. Same scale, same axes: shape differences become immediately readable.

**Reference:** https://launchyourvibe.live/card/d-05

### D-06 — Use Accessible Palettes in Data Visualization

**When:** Working on use accessible palettes in data visualization (Data)

**Rule:** **Never rely on red vs. green to distinguish data series.** Use palettes designed for colorblind users (IBM Carbon, ColorBrewer, Tableau colorblind). Pair color differences with shape, texture, or direct labeling so the chart works without color at all.

**Reference:** https://launchyourvibe.live/card/d-06

### D-07 — Tables for Lookup. Charts for Patterns.

**When:** Choosing between a chart and a table for numeric data

**Rule:** **Charts reveal patterns; tables reveal values.** If a user needs to look up a specific number, a table serves them better than a chart. If they need to understand a trend, distribution, or comparison across categories, a chart does what a table can't.

**Reference:** https://launchyourvibe.live/card/d-07

### D-08 — Sparklines: Trend at a Glance

**When:** Working on sparklines: trend at a glance (Data)

**Rule:** **Sparklines pack trend context into a single row.** They're not for precise reading: they're for direction and shape at a glance. Pair them with a KPI value. Omit axis labels; the shape is the message. Perfect for dashboards with many metrics in limited space.

**Reference:** https://launchyourvibe.live/card/d-08

### D-09 — Reduce Data Density on Mobile

**When:** Working on reduce data density on mobile (Data)

**Rule:** **Mobile screens are too narrow for complex chart layouts.** Reduce the number of data points, consolidate time periods (months → quarters), increase label size, and favor horizontal bar charts over vertical ones where space is constrained. Link to a fuller view if detail matters.

**Reference:** https://launchyourvibe.live/card/d-09

### D-10 — Chart Tooltips: Detail on Demand

**When:** Working on chart tooltips: detail on demand (Data)

**Rule:** **Tooltips layer precise values onto a chart without cluttering it.** Don't rely on them as the only access to important data: mobile users must tap to trigger them, and they're invisible until interaction. Design for the chart to communicate its core message without tooltip dependency.

**Reference:** https://launchyourvibe.live/card/d-10

### D-11 — Bar Charts Start at Zero. Always.

**When:** Working on bar charts start at zero. always. (Data)

**Rule:** **Truncating a bar chart's y-axis turns minor differences into apparent crises.** Bar height encodes quantity: cutting the baseline misrepresents proportions. Line charts can use non-zero baselines to show variance; bar charts cannot. If differences are small, consider a line chart instead.

**Reference:** https://launchyourvibe.live/card/d-11

### D-12 — Donut Charts: Add a Summary KPI in the Center

**When:** Working on donut charts: add a summary kpi in the center (Data)

**Rule:** **The donut chart's hole is prime real estate.** Use it for the single most important number: total, percentage complete, or a key KPI. Without a center value, a donut chart is just a pie with a hole: the center makes it meaningfully different.

**Reference:** https://launchyourvibe.live/card/d-12

### D-13 — Stacked Bars Mislead Middle Segments

**When:** Working on stacked bars mislead middle segments (Data)

**Rule:** **Stacked bars only allow accurate comparison of the bottom segment and the total.** Middle segments float on different baselines, making comparison nearly impossible. If comparing sub-categories matters, use grouped bars. Use stacked bars only when total and bottom segment are the story.

**Reference:** https://launchyourvibe.live/card/d-13

### D-14 — Layer Data: Summary First, Detail on Demand

**When:** Working on layer data: summary first, detail on demand (Data)

**Rule:** **Most users want the headline; a few want the footnotes.** Lead with the single most important number and its trend. Let users drill into breakdown views only if they choose. Showing everything at once creates dashboards that exhaust instead of inform.

**Reference:** https://launchyourvibe.live/card/d-14

### D-15 — Chart Titles State the Insight, Not the Subject

**When:** Working on chart titles state the insight, not the subject (Data)

**Rule:** **A subject title labels the chart. An insight title does the analysis for the reader.** Move the descriptive label to a subtitle. The title should complete the sentence: "The main thing this chart shows is ___." Users shouldn't have to read and interpret: they should arrive at the conclusion immediately.

**Reference:** https://launchyourvibe.live/card/d-15

# LaunchYourVibe — Security

Optional Security rules from LaunchYourVibe. Enable this rule when working in this domain.

### S-01 — Filter by User ID. Always.

**When:** Handling authentication, login, or session management

**Rule:** **Every user-specific fetch must filter by the authenticated user's ID.** Test it by logging in as User A and manually requesting User B's data. If you can see it, you have a problem. This isn't a platform feature you toggle on — it's a check you write and verify.

**Reference:** https://launchyourvibe.live/card/s-01

### S-02 — Use Supabase, Clerk, or Auth0.

**When:** Storing secrets, API keys, or credentials in code or config

**Rule:** **Rolling your own session management is where breaches are born.** Use Supabase Auth, Clerk, or Auth0. They handle tokens, refresh, MFA, and OAuth so you don't have to — and they stay patched when new vulnerabilities emerge.

**Reference:** https://launchyourvibe.live/card/s-02

### S-03 — Hiding a Button Is Not Security.

**When:** Protecting routes, APIs, admin actions, or sensitive data

**Rule:** **Every protected action checks the session on the server before returning data.** UI-only access control is theater — a crafted request bypasses it in seconds. Hiding a button is not access control.

**Reference:** https://launchyourvibe.live/card/s-03

### S-04 — Client Code Is Public Code.

**When:** Working on client code is public code. (Security)

**Rule:** **Anything shipped to the client is public.** API keys, service role keys, admin flags — none of it belongs in frontend code. If it's in your bundle, assume everyone can read it.

**Reference:** https://launchyourvibe.live/card/s-04

### S-05 — .env in Gitignore. Rotate if Exposed.

**When:** Working on .env in gitignore. rotate if exposed. (Security)

**Rule:** **Committed secrets live in history forever even after deletion.** Gitignore .env and rotate anything that ever shipped. A deleted line in today's code doesn't erase yesterday's commit.

**Reference:** https://launchyourvibe.live/card/s-05

### S-06 — Parameterize Every Query.

**When:** Working on parameterize every query. (Security)

**Rule:** **Raw string concatenation in queries is how SQL injection happens.** Parameterized queries are non-negotiable — let the database engine separate data from instructions.

**Reference:** https://launchyourvibe.live/card/s-06

### S-07 — localStorage = Readable by Any Script.

**When:** Persisting auth tokens (JWT, session) in the browser

**Rule:** **JWTs stored in localStorage are readable by any script on the page.** httpOnly cookies are not. One XSS vulnerability with localStorage tokens = full account takeover.

**Reference:** https://launchyourvibe.live/card/s-07

### S-08 — Lock Out After 5–10 Failures.

**When:** Working on lock out after 5–10 failures. (Security)

**Rule:** **Unlimited login attempts are a brute force welcome mat.** Throttle or lock after 5–10 failures. Add exponential backoff and alert on suspicious patterns.

**Reference:** https://launchyourvibe.live/card/s-08

### S-09 — Never Trust the Client.

**When:** Working on never trust the client. (Security)

**Rule:** **Everything reaching the database is checked for type, length, and allowed values.** Client-side validation is UX convenience, not security — it can be bypassed with a single curl command.

**Reference:** https://launchyourvibe.live/card/s-09

### S-10 — User Content Is Untrusted HTML.

**When:** Rendering user-generated or untrusted HTML/content

**Rule:** **User-generated content rendered directly to the DOM is an XSS vector.** Escape or sanitize everything that came from a user before it touches the page.

**Reference:** https://launchyourvibe.live/card/s-10

### S-11 — Including Staging. No Exceptions.

**When:** Working on including staging. no exceptions. (Security)

**Rule:** **HTTPS everywhere, always — no exceptions, including staging.** Let's Encrypt makes this free. There is no excuse — credentials and tokens travel in plaintext without it.

**Reference:** https://launchyourvibe.live/card/s-11

### S-12 — Search for key, secret, token.

**When:** Working on search for key, secret, token. (Security)

**Rule:** **Search your codebase for key, secret, token, password before every deploy.** One command, five minutes, no surprises. Make it part of your ship checklist.

**Reference:** https://launchyourvibe.live/card/s-12

### S-13 — Old Commits Keep Secrets Forever.

**When:** Working on old commits keep secrets forever. (Security)

**Rule:** **Before going public, run a secret scanner on your commit history.** You'd be surprised what's buried in old commits — deleted files don't delete the history.

**Reference:** https://launchyourvibe.live/card/s-13

### S-14 — npm audit Before Launch.

**When:** Working on npm audit before launch. (Security)

**Rule:** **Run npm audit or equivalent before launch.** Known vulnerabilities in packages you didn't write are still your problem — transitive dependencies included.

**Reference:** https://launchyourvibe.live/card/s-14

### S-15 — Rotate First. Investigate Second.

**When:** Working on rotate first. investigate second. (Security)

**Rule:** **The moment you suspect exposure, rotate first, investigate second.** Stop the bleeding before you figure out the wound. A compromised key still works until you revoke it.

**Reference:** https://launchyourvibe.live/card/s-15

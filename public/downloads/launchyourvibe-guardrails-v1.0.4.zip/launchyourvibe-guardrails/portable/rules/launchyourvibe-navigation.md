# LaunchYourVibe — Navigation

Optional Navigation rules from LaunchYourVibe. Enable this rule when working in this domain.

### N-01 — Empty States Are Not Optional

**When:** Rendering empty lists, dashboards, inboxes, or zero-result states

**Rule:** **Every empty screen is a first impression of a feature.** Tell them what belongs here, why it's empty, and exactly what to do next. Icon + headline + CTA. Three elements, every time.

**Reference:** https://launchyourvibe.live/card/n-01

### N-02 — New Screen or Overlay? Ask About Context.

**When:** Choosing between a modal/dialog and a new page or route

**Rule:** **The choice is really about whether the user is leaving their current task or pausing it.** If they're leaving, push a new screen. If they're pausing, use an overlay that lets them see and return to where they came from.

**Reference:** https://launchyourvibe.live/card/n-02

### N-03 — Back Should Go Back. Not Somewhere Weird.

**When:** Working on back should go back. not somewhere weird. (Navigation)

**Rule:** **Back is the most-used navigation action.** When it teleports users somewhere unexpected, they lose their mental map of the app. Maintain a proper back stack: always. Test deep links specifically.

**Reference:** https://launchyourvibe.live/card/n-03

### N-04 — Delay Onboarding Until Users Need It

**When:** Working on delay onboarding until users need it (Navigation)

**Rule:** **Users skip onboarding they haven't earned yet.** Show guidance at the moment it becomes relevant: not before. Empty states, coach marks, and contextual tooltips teach while users are actually doing the thing.

**Reference:** https://launchyourvibe.live/card/n-04

### N-05 — Every Screen Should Be Deep-Linkable

**When:** Working on every screen should be deep-linkable (Navigation)

**Rule:** **If you can't link to it, you can't share it, bookmark it, or return to it.** Every meaningful screen in your app should have a URL that restores its full state. This also forces you to design URL-safe navigation.

**Reference:** https://launchyourvibe.live/card/n-05

### N-06 — Tab Bar: 3–5 Items. No More.

**When:** Working on tab bar: 3–5 items. no more. (Navigation)

**Rule:** **Beyond 5 tabs, labels disappear and icons carry everything.** If you have 6+ destinations, restructure the IA: nest them, or use a different nav pattern. Tab bars are for top-level, equal-weight destinations.

**Reference:** https://launchyourvibe.live/card/n-06

### N-07 — Breadcrumbs for Deep Hierarchies Only

**When:** Working on breadcrumbs for deep hierarchies only (Navigation)

**Rule:** **Breadcrumbs tell you where you are in a hierarchy: not history.** They're a map, not a back button. On mobile, replace with just a Back label showing the parent's name.

**Reference:** https://launchyourvibe.live/card/n-07

### N-08 — Settings = Profile Menu. Not a Main Tab.

**When:** Working on settings = profile menu. not a main tab. (Navigation)

**Rule:** **Settings is infrequently used.** Reserve primary tab real estate for actions users take every session. Settings lives naturally under the profile: where every mobile convention has trained users to look.

**Reference:** https://launchyourvibe.live/card/n-08

### N-09 — Delay Login Until the User Has a Reason

**When:** Working on delay login until the user has a reason (Navigation)

**Rule:** **Login walls at launch filter out users who haven't seen the value yet.** Let users experience the app before asking for commitment. Gate only actions that genuinely require an account.

**Reference:** https://launchyourvibe.live/card/n-09

### N-10 — Gestures Must Be Taught or Discoverable

**When:** Working on gestures must be taught or discoverable (Navigation)

**Rule:** **Gestures are invisible: they don't announce themselves.** Animate a partial gesture on first load, show a hint overlay, or reveal a "Did you know?" prompt. Never rely on discoverability alone for critical actions.

**Reference:** https://launchyourvibe.live/card/n-10

### N-11 — Ask for Notifications After Showing Their Value

**When:** Working on ask for notifications after showing their value (Navigation)

**Rule:** **Permission prompts fail when the user has no context for what they're agreeing to.** Link the ask to a specific action the user just took. The value exchange is clear, and they're far more likely to say yes.

**Reference:** https://launchyourvibe.live/card/n-11

### N-12 — Design the Exit: Offboarding Matters

**When:** Working on design the exit: offboarding matters (Navigation)

**Rule:** **How users leave shapes how they remember you.** Dark patterns at offboarding (roach motel UX) create resentment and reviews. A clean, honest exit is a final brand impression, and sometimes brings people back.

**Reference:** https://launchyourvibe.live/card/n-12

### N-13 — Error Screens Need a Path Forward

**When:** Working on error screens need a path forward (Navigation)

**Rule:** **Dead ends destroy trust.** Every error screen needs at minimum: what happened (briefly), and a clear path forward. A search field is a bonus. Never leave the user with only a browser back button.

**Reference:** https://launchyourvibe.live/card/n-13

### N-14 — Primary Actions Don't Belong Below the Fold

**When:** Working on primary actions don't belong below the fold (Navigation)

**Rule:** **The fold is not dead.** On small screens, most users never scroll. Put the primary CTA in the viewport on load. Everything else can follow: but the first action the user should take must be immediately visible.

**Reference:** https://launchyourvibe.live/card/n-14

### N-15 — Preserve State When Users Leave and Return

**When:** Working on preserve state when users leave and return (Navigation)

**Rule:** **Users don't live inside your app.** They switch apps, get interrupted, background it. Persist form data, scroll position, and filter state. Losing work is one of the fastest ways to lose users permanently.

**Reference:** https://launchyourvibe.live/card/n-15

# LaunchYourVibe — Accessibility

Optional Accessibility rules from LaunchYourVibe. Enable this rule when working in this domain.

### A-01 — Contrast Ratios: AA vs AAA

**When:** Working on contrast ratios: aa vs aaa (Accessibility)

**Rule:** **AA is the legal baseline; AAA is the gold standard.** Body text needs 4.5:1. Large text (18pt+ or 14pt+ bold) needs 3:1. UI components and icons need 3:1 against adjacent colors. Test with a real contrast checker: eyeballing fails.

**Reference:** https://launchyourvibe.live/card/a-01

### A-02 — Touch Target Minimum Sizes

**When:** Working on touch target minimum sizes (Accessibility)

**Rule:** **A visually small element can still have a large hit area.** iOS requires 44×44pt, Android recommends 48×48dp. Use padding to expand the tap zone without changing visual size. Crowded targets need 8pt spacing between them.

**Reference:** https://launchyourvibe.live/card/a-02

### A-03 — Focus Indicators Must Be Visible

**When:** Working on focus indicators must be visible (Accessibility)

**Rule:** **Keyboard users navigate entirely by focus ring.** Never suppress it with `outline: none` without a custom replacement. Focus must meet 3:1 contrast against adjacent colors. Use `:focus-visible` to show it only for keyboard, not mouse.

**Reference:** https://launchyourvibe.live/card/a-03

### A-04 — Every Interactive Element Needs a Label

**When:** Creating icon-only buttons or controls with no visible text label

**Rule:** **Icon buttons are invisible to screen readers without labels.** Add `aria-label` to every icon-only button. Use `aria-labelledby` when a visible label exists nearby. The label should describe the action, not the icon.

**Reference:** https://launchyourvibe.live/card/a-04

### A-05 — Semantic HTML: Structure Is Meaning

**When:** Choosing HTML elements (buttons, links, headings, landmarks) for structure

**Rule:** **HTML elements carry meaning that assistive tech relies on.** Use `<button>` for actions, `<a>` for navigation, and heading tags in sequential order. Screen readers use landmark elements (`main`, `nav`, `aside`) to let users jump between page sections.

**Reference:** https://launchyourvibe.live/card/a-05

### A-06 — Color Alone Is Not Enough

**When:** Working on color alone is not enough (Accessibility)

**Rule:** **Red/green distinctions are invisible to 8% of users.** Always pair color with a second signal: an icon, a label, a pattern, or a shape. This applies to charts, status indicators, form errors, and any state communicated purely through hue.

**Reference:** https://launchyourvibe.live/card/a-06

### A-07 — Support Text Resize Up to 200%

**When:** Working on support text resize up to 200% (Accessibility)

**Rule:** **Low-vision users regularly set system font size to 150–200%.** Use relative units (rem, em): never px for font sizes. Test by bumping browser font size to 200% and checking for content loss, overflow, or broken layouts. Mobile: respect system dynamic type settings.

**Reference:** https://launchyourvibe.live/card/a-07

### A-08 — Respect Reduced Motion Preferences

**When:** Working on respect reduced motion preferences (Accessibility)

**Rule:** **Parallax, auto-playing carousels, and screen-wide transitions can trigger vestibular disorders.** Check `prefers-reduced-motion` and remove or minimize non-essential animation. Keep functional transitions (loading, focus)...eliminate decorative ones.

**Reference:** https://launchyourvibe.live/card/a-08

### A-09 — Labels Always Visible: Never Placeholder-Only

**When:** Adding form inputs, search fields, or any text field

**Rule:** **Placeholders vanish when users start typing.** This breaks cognitive load for anyone who forgets what a field was, and breaks screen readers entirely. Use a persistent `<label>` element for every input. Placeholder text is fine for examples: not for labels.

**Reference:** https://launchyourvibe.live/card/a-09

### A-10 — Link Errors to Their Fields Programmatically

**When:** Showing validation errors, helper text, or inline field feedback

**Rule:** **Screen readers don't infer visual proximity.** Use `aria-describedby` to link the error message to its input, and `role="alert"` so it's announced immediately when it appears. `aria-invalid="true"` also signals the field state.

**Reference:** https://launchyourvibe.live/card/a-10

### A-11 — Skip Navigation Links Save Keyboard Users

**When:** Working on skip navigation links save keyboard users (Accessibility)

**Rule:** **Keyboard users Tab through every nav item on every page load.** A skip link lets them jump directly to main content. Place it as the very first focusable element. Visually hide it until focused: don't remove it from the DOM or tab order.

**Reference:** https://launchyourvibe.live/card/a-11

### A-12 — Alt Text: Describe the Purpose, Not the Pixels

**When:** Working on alt text: describe the purpose, not the pixels (Accessibility)

**Rule:** **Alt text should convey what the image communicates in context.** If the image is pure decoration, use an empty alt attribute (`alt=""`) so screen readers skip it. If it's a chart, describe the key insight: not the visual style.

**Reference:** https://launchyourvibe.live/card/a-12

### A-13 — DOM Order = Reading Order

**When:** Working on dom order = reading order (Accessibility)

**Rule:** **Screen readers follow the DOM: not what's visible on screen.** Using CSS `order`, `float`, or absolute positioning to rearrange visuals without reordering HTML creates a disjointed reading experience for keyboard and screen reader users.

**Reference:** https://launchyourvibe.live/card/a-13

### A-14 — Icon Buttons Need Accessible Names

**When:** Naming interactive elements for screen readers (buttons, links, inputs)

**Rule:** **The accessible name is what screen readers announce.** For icon-only buttons the visual label is the icon: which is meaningless to AT. Pick the strategy that fits: `aria-label` for standalone icons, visually-hidden text when you need translatable strings, `aria-labelledby` when a visible label exists nearby.

**Reference:** https://launchyourvibe.live/card/a-14

### A-15 — WCAG Levels: A, AA, and AAA in Practice

**When:** Working on wcag levels: a, aa, and aaa in practice (Accessibility)

**Rule:** **AA is the target for most products, and what most accessibility laws require.** AAA is aspirational and not required for entire sites. Start with AA conformance, document your approach, and layer in AAA where it meaningfully serves your users.

**Reference:** https://launchyourvibe.live/card/a-15

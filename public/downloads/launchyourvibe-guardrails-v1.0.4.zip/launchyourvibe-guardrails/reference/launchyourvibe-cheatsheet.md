# LaunchYourVibe Cheat Sheet

119 reference cards for vibe coders. Visual deck: https://launchyourvibe.live

This file is for human lookup — not for loading into agent context.

# Spacing & Typography

## T-01 — Fluid Type: rem + clamp()

**Domain:** Spacing & Typography

**Px breakpoints snap; user settings get ignored.** Set type in rem and scale smoothly with clamp(): a minimum rem, a viewport-relative middle term, and a maximum rem. One formula replaces separate mobile and desktop charts.

[View card →](https://launchyourvibe.live/card/t-01)

## T-02 — The 8pt Grid: Spacing in rem

**Domain:** Spacing & Typography

**Arbitrary spacing makes screens feel unsteady.** Snap component gaps and padding to rem (0.25rem steps on an 8pt grid). For page-level breathing room, use vw in clamp() so gutters grow with the viewport.

[View card →](https://launchyourvibe.live/card/t-02)

## T-03 — Line Length: 45–75 Characters

**Domain:** Spacing & Typography

**Long lines force the eye to hunt for the next line.** Short columns increase jumps per paragraph. 45–75 chars is where reading becomes effortless.

[View card →](https://launchyourvibe.live/card/t-03)

## T-04 — Weight Does the Hierarchy Work

**Domain:** Spacing & Typography

**Color and size aren't the only tools.** Weight creates hierarchy even in a single color. Use 400 for body, 600 for labels, 700 for headings: avoid everything in between.

[View card →](https://launchyourvibe.live/card/t-04)

## T-05 — Line Height by Text Role

**Domain:** Spacing & Typography

**Tight headings look intentional. Tight body text looks like a bug.** Body line-height starts at 1.5 (WCAG). Button height comes from padding, not cramping line-height to 1.0.

[View card →](https://launchyourvibe.live/card/t-05)

## T-06 — Padding vs Margin: Inside vs Outside

**Domain:** Spacing & Typography

**Padding changes the element's feel; margin changes its relationship to neighbors.** Use padding to make a button feel spacious. Use margin to create breathing room in a layout.

[View card →](https://launchyourvibe.live/card/t-06)

## T-07 — Visual Hierarchy: 3 Levels Maximum

**Domain:** Spacing & Typography

**Every level you add competes with the others.** Primary, secondary, and body. That's the hierarchy. Adding a fourth level usually means the third was doing too much.

[View card →](https://launchyourvibe.live/card/t-07)

## T-08 — Whitespace Is a Design Element

**Domain:** Spacing & Typography

**Space is not empty: it's structure.** Generous spacing reduces cognitive load. The gaps between elements tell users which things belong together and what's a separate thought.

[View card →](https://launchyourvibe.live/card/t-08)

## T-09 — Left-Align Body Text. Center Sparingly.

**Domain:** Spacing & Typography

**Centered multi-line text is the hallmark of amateur design.** The ragged left edge forces the eye to hunt for the start of each new line. Left-align everything longer than a headline.

[View card →](https://launchyourvibe.live/card/t-09)

## T-10 — Two Font Families. That's the Budget.

**Domain:** Spacing & Typography

**Example font families in clear roles feel like a system.** Bold and regular are the same family, not a second one. Mixing families without roles creates noise. Three or more feel like you couldn't decide.

[View card →](https://launchyourvibe.live/card/t-10)

## T-12 — Letter Spacing: Where It Helps

**Domain:** Spacing & Typography

**Tight letter spacing on big type is a design move. Tight spacing on small type is illegible.** The smaller the text, the more spacing it needs: not less. Never tighten body text.

[View card →](https://launchyourvibe.live/card/t-12)

## T-13 — Proximity Creates Visual Grouping

**Domain:** Spacing & Typography

**A label 8px from its field looks owned. A label 16px away looks like a heading.** The gap between things signals their relationship: closer means "these belong together."

[View card →](https://launchyourvibe.live/card/t-13)

## T-14 — Safe Zones: Respect the Hardware

**Domain:** Spacing & Typography

**UI placed in the notch or behind the home indicator isn't just ugly: it's unusable.** Use CSS env() safe-area variables so your layout always respects the device's hardware edges.

[View card →](https://launchyourvibe.live/card/t-14)

## T-15 — Color + Type: Two Signals Are Enough

**Domain:** Spacing & Typography

**Color alone fails for colorblind users.** Pair every color-coded state with a second signal: an icon, label, or shape. This isn't accessibility extra credit; it's baseline UX.

[View card →](https://launchyourvibe.live/card/t-15)

# Interaction

## I-01 — Every Button Needs 4 States.

**Domain:** Interaction

**Missing a state isn't neutral.** No disabled state feels broken when nothing happens. Each state signals what's possible right now.

[View card →](https://launchyourvibe.live/card/i-01)

## I-02 — Error Messages: Say What + Why + Fix

**Domain:** Interaction

**What happened. Why. What to do.** Three sentences max. Plain language. No stack traces. Never blame the user.

[View card →](https://launchyourvibe.live/card/i-02)

## I-03 — Loading: Match the Wait to the Pattern

**Domain:** Interaction

**Blank screens feel broken; spinners feel slow.** Use skeleton loaders for content-heavy loads. Spinners for <2s actions. Progress bars when the user needs to know how long.

[View card →](https://launchyourvibe.live/card/i-03)

## I-04 — Destructive Actions Need Friction: On Purpose

**Domain:** Interaction

**Make the danger legible.** Red button, explicit label, and a cost statement. "Are you sure?" without consequences doesn't create real friction: specifics do.

[View card →](https://launchyourvibe.live/card/i-04)

## I-05 — Success Is a Moment. Mark It.

**Domain:** Interaction

**Silence after a successful action breeds doubt.** Confirm what happened, to whom, and what comes next. The user's mental model needs closure.

[View card →](https://launchyourvibe.live/card/i-05)

## I-06 — Toast = Info. Dialog = Decision.

**Domain:** Interaction

**Dialogs steal focus because they have to.** If the user can ignore it, use a toast. If they must choose, use a dialog. Never use a dialog to say something they don't need to act on.

[View card →](https://launchyourvibe.live/card/i-06)

## I-07 — Validate on Blur, Not on Keystroke

**Domain:** Interaction

**Showing errors while someone is mid-thought is hostile.** Wait for blur (field exit) to validate. Only re-validate on keystroke after the first error appears. Never on every character.

[View card →](https://launchyourvibe.live/card/i-07)

## I-08 — Optimistic UI: Show Success First

**Domain:** Interaction

**Most requests succeed.** Assume success, update the UI immediately, sync in the background. Roll back only on actual failure. The app feels instant even when it isn't.

[View card →](https://launchyourvibe.live/card/i-08)

## I-09 — Undo Beats Confirm Dialogs

**Domain:** Interaction

**Confirms interrupt flow. Undo restores agency.** Let users act immediately, then give them a short window to reverse it. They feel more in control, not less.

[View card →](https://launchyourvibe.live/card/i-09)

## I-10 — Every Tap Needs Immediate Feedback

**Domain:** Interaction

**Without feedback, users tap twice.** Response within 100ms feels instantaneous. 100–300ms feels fast. Beyond 300ms, users start to doubt. Give visual feedback first, everything else second.

[View card →](https://launchyourvibe.live/card/i-10)

## I-11 — Progress: Show Where They Are

**Domain:** Interaction

**Progress without context is just anxiety.** Show step number, percentage, or time estimate. Giving users a frame of reference reduces perceived wait time by 40%.

[View card →](https://launchyourvibe.live/card/i-11)

## I-12 — Hover Actions Don't Exist on Mobile

**Domain:** Interaction

**Touch has no cursor.** Any interaction hidden behind hover is invisible on mobile. If your content needs additional actions, make them visible, not discoverable via pointer proximity.

[View card →](https://launchyourvibe.live/card/i-12)

## I-13 — Disabled Means "Not Yet": Explain Why

**Domain:** Interaction

**A grayed button with no explanation creates confusion.** Tell users what they're missing. The block becomes a guide, and prevents them from abandoning the form in frustration.

[View card →](https://launchyourvibe.live/card/i-13)

## I-14 — Swipe Actions Need Visual Teaching

**Domain:** Interaction

**Gestures are invisible until taught.** On first use, animate a partial swipe. Use destructive actions only on one side: left for danger is a convention users already know.

[View card →](https://launchyourvibe.live/card/i-14)

## I-15 — Right Keyboard for Every Input

**Domain:** Interaction

**The wrong keyboard is a tiny betrayal of trust.** A number pad for phone numbers, @ key for emails: set inputmode or type correctly and the keyboard is already optimized.

[View card →](https://launchyourvibe.live/card/i-15)

# Components

## C-01 — Modal → Desktop Bottom Sheet → Mobile

**Domain:** Components

**Modals trap thumbs.** On mobile, a centered dialog requires two-handed use. A bottom sheet rises from where thumbs already live. Same intent. Opposite ergonomics.

[View card →](https://launchyourvibe.live/card/c-01)

## C-02 — Tab Bar → Mobile Sidebar → Desktop

**Domain:** Components

**Thumb reach dictates nav placement.** Bottom tabs stay in the natural grip zone on mobile. Sidebars use the screen width that desktop has to spare. Never swap them.

[View card →](https://launchyourvibe.live/card/c-02)

## C-03 — Forms Are Always Single Column on Mobile

**Domain:** Components

**Two columns on mobile means two columns of tiny inputs.** Users skip fields accidentally and make more errors. Single column, full width. One field, one decision at a time.

[View card →](https://launchyourvibe.live/card/c-03)

## C-04 — Toggle = Immediate. Checkbox = On Submit.

**Domain:** Components

**Toggles are instant actions. Checkboxes are selection within a form.** If the setting takes effect the moment you flip it (like dark mode), use a toggle. If it's part of a group submitted together, use checkboxes.

[View card →](https://launchyourvibe.live/card/c-04)

## C-05 — Cards for Browse. Lists for Scan.

**Domain:** Components

**Cards invite exploration; lists support comparison.** Use cards when each item has rich media or requires its own visual weight. Use lists when users are scanning for a specific item quickly.

[View card →](https://launchyourvibe.live/card/c-05)

## C-06 — Dropdowns on Mobile: Use Native or Bottom Sheet

**Domain:** Components

**Custom dropdowns fight the OS.** Native selects trigger the platform's built-in scroll picker: optimized for touch. Only build custom when the native control genuinely fails the need.

[View card →](https://launchyourvibe.live/card/c-06)

## C-07 — FAB = One Primary Action. One.

**Domain:** Components

**The FAB is the most prominent tap target on screen.** It implies "this is the thing you do most." If you can't name that one action, the FAB isn't the right pattern.

[View card →](https://launchyourvibe.live/card/c-07)

## C-08 — Chips: Filter or Select, Not Both at Once

**Domain:** Components

**Chips have two distinct jobs: filtering and input.** Don't mix them on the same surface. Filter chips are toggles. Input chips represent values the user has added. Styling should signal the difference.

[View card →](https://launchyourvibe.live/card/c-08)

## C-09 — Accordions Hide Content. Use Them Intentionally.

**Domain:** Components

**Accordions create extra work for the user.** Every collapsed section is a barrier. Use them when the content is genuinely optional: not to make a page feel shorter while hiding required reading.

[View card →](https://launchyourvibe.live/card/c-09)

## C-10 — Date Pickers: Match the Date Type

**Domain:** Components

**There is no universal date picker.** Picking a birthday is a different task than scheduling a meeting. The interface should match the cognitive model: not force a calendar view on every date type.

[View card →](https://launchyourvibe.live/card/c-10)

## C-11 — 4 Alert Levels. Don't Cry Wolf.

**Domain:** Components

**Every alert in red trains users to ignore red.** Reserve error alerts for actual errors. Info banners for context. If everything is urgent, nothing is. Overused alerts become wallpaper.

[View card →](https://launchyourvibe.live/card/c-11)

## C-12 — Search Placement Signals Its Importance

**Domain:** Components

**If search is how most users navigate, it belongs at the top: always visible.** If it's a power-user feature, tuck it in nav. Never make it a modal activation or a tiny corner icon on search-first apps.

[View card →](https://launchyourvibe.live/card/c-12)

## C-13 — Steppers for Small Ranges. Input for Large.

**Domain:** Components

**Steppers work for small, bounded quantities.** If someone might want 500 of something, don't make them tap 499 times. Offer a direct input. Steppers should cover ranges users reach in under 10 taps.

[View card →](https://launchyourvibe.live/card/c-13)

## C-14 — Tooltips Are for Desktop Power Users

**Domain:** Components

**If users need a tooltip to use a feature, the feature needs better labeling.** Tooltips are bonus context for experienced users: not a substitute for clear UI copy. And they don't exist on touch screens.

[View card →](https://launchyourvibe.live/card/c-14)

## C-15 — Infinite Scroll for Browse. Pagination for Find.

**Domain:** Components

**Infinite scroll removes the user's sense of location.** If they need to return to a specific item or share a result, pagination gives them an address. Endless scroll is for consuming, not finding.

[View card →](https://launchyourvibe.live/card/c-15)

# Navigation

## N-01 — Empty States Are Not Optional

**Domain:** Navigation

**Every empty screen is a first impression of a feature.** Tell them what belongs here, why it's empty, and exactly what to do next. Icon + headline + CTA. Three elements, every time.

[View card →](https://launchyourvibe.live/card/n-01)

## N-02 — New Screen or Overlay? Ask About Context.

**Domain:** Navigation

**The choice is really about whether the user is leaving their current task or pausing it.** If they're leaving, push a new screen. If they're pausing, use an overlay that lets them see and return to where they came from.

[View card →](https://launchyourvibe.live/card/n-02)

## N-03 — Back Should Go Back. Not Somewhere Weird.

**Domain:** Navigation

**Back is the most-used navigation action.** When it teleports users somewhere unexpected, they lose their mental map of the app. Maintain a proper back stack: always. Test deep links specifically.

[View card →](https://launchyourvibe.live/card/n-03)

## N-04 — Delay Onboarding Until Users Need It

**Domain:** Navigation

**Users skip onboarding they haven't earned yet.** Show guidance at the moment it becomes relevant: not before. Empty states, coach marks, and contextual tooltips teach while users are actually doing the thing.

[View card →](https://launchyourvibe.live/card/n-04)

## N-05 — Every Screen Should Be Deep-Linkable

**Domain:** Navigation

**If you can't link to it, you can't share it, bookmark it, or return to it.** Every meaningful screen in your app should have a URL that restores its full state. This also forces you to design URL-safe navigation.

[View card →](https://launchyourvibe.live/card/n-05)

## N-06 — Tab Bar: 3–5 Items. No More.

**Domain:** Navigation

**Beyond 5 tabs, labels disappear and icons carry everything.** If you have 6+ destinations, restructure the IA: nest them, or use a different nav pattern. Tab bars are for top-level, equal-weight destinations.

[View card →](https://launchyourvibe.live/card/n-06)

## N-07 — Breadcrumbs for Deep Hierarchies Only

**Domain:** Navigation

**Breadcrumbs tell you where you are in a hierarchy: not history.** They're a map, not a back button. On mobile, replace with just a Back label showing the parent's name.

[View card →](https://launchyourvibe.live/card/n-07)

## N-08 — Settings = Profile Menu. Not a Main Tab.

**Domain:** Navigation

**Settings is infrequently used.** Reserve primary tab real estate for actions users take every session. Settings lives naturally under the profile: where every mobile convention has trained users to look.

[View card →](https://launchyourvibe.live/card/n-08)

## N-09 — Delay Login Until the User Has a Reason

**Domain:** Navigation

**Login walls at launch filter out users who haven't seen the value yet.** Let users experience the app before asking for commitment. Gate only actions that genuinely require an account.

[View card →](https://launchyourvibe.live/card/n-09)

## N-10 — Gestures Must Be Taught or Discoverable

**Domain:** Navigation

**Gestures are invisible: they don't announce themselves.** Animate a partial gesture on first load, show a hint overlay, or reveal a "Did you know?" prompt. Never rely on discoverability alone for critical actions.

[View card →](https://launchyourvibe.live/card/n-10)

## N-11 — Ask for Notifications After Showing Their Value

**Domain:** Navigation

**Permission prompts fail when the user has no context for what they're agreeing to.** Link the ask to a specific action the user just took. The value exchange is clear, and they're far more likely to say yes.

[View card →](https://launchyourvibe.live/card/n-11)

## N-12 — Design the Exit: Offboarding Matters

**Domain:** Navigation

**How users leave shapes how they remember you.** Dark patterns at offboarding (roach motel UX) create resentment and reviews. A clean, honest exit is a final brand impression, and sometimes brings people back.

[View card →](https://launchyourvibe.live/card/n-12)

## N-13 — Error Screens Need a Path Forward

**Domain:** Navigation

**Dead ends destroy trust.** Every error screen needs at minimum: what happened (briefly), and a clear path forward. A search field is a bonus. Never leave the user with only a browser back button.

[View card →](https://launchyourvibe.live/card/n-13)

## N-14 — Primary Actions Don't Belong Below the Fold

**Domain:** Navigation

**The fold is not dead.** On small screens, most users never scroll. Put the primary CTA in the viewport on load. Everything else can follow: but the first action the user should take must be immediately visible.

[View card →](https://launchyourvibe.live/card/n-14)

## N-15 — Preserve State When Users Leave and Return

**Domain:** Navigation

**Users don't live inside your app.** They switch apps, get interrupted, background it. Persist form data, scroll position, and filter state. Losing work is one of the fastest ways to lose users permanently.

[View card →](https://launchyourvibe.live/card/n-15)

# Accessibility

## A-01 — Contrast Ratios: AA vs AAA

**Domain:** Accessibility

**AA is the legal baseline; AAA is the gold standard.** Body text needs 4.5:1. Large text (18pt+ or 14pt+ bold) needs 3:1. UI components and icons need 3:1 against adjacent colors. Test with a real contrast checker: eyeballing fails.

[View card →](https://launchyourvibe.live/card/a-01)

## A-02 — Touch Target Minimum Sizes

**Domain:** Accessibility

**A visually small element can still have a large hit area.** iOS requires 44×44pt, Android recommends 48×48dp. Use padding to expand the tap zone without changing visual size. Crowded targets need 8pt spacing between them.

[View card →](https://launchyourvibe.live/card/a-02)

## A-03 — Focus Indicators Must Be Visible

**Domain:** Accessibility

**Keyboard users navigate entirely by focus ring.** Never suppress it with `outline: none` without a custom replacement. Focus must meet 3:1 contrast against adjacent colors. Use `:focus-visible` to show it only for keyboard, not mouse.

[View card →](https://launchyourvibe.live/card/a-03)

## A-04 — Every Interactive Element Needs a Label

**Domain:** Accessibility

**Icon buttons are invisible to screen readers without labels.** Add `aria-label` to every icon-only button. Use `aria-labelledby` when a visible label exists nearby. The label should describe the action, not the icon.

[View card →](https://launchyourvibe.live/card/a-04)

## A-05 — Semantic HTML: Structure Is Meaning

**Domain:** Accessibility

**HTML elements carry meaning that assistive tech relies on.** Use `<button>` for actions, `<a>` for navigation, and heading tags in sequential order. Screen readers use landmark elements (`main`, `nav`, `aside`) to let users jump between page sections.

[View card →](https://launchyourvibe.live/card/a-05)

## A-06 — Color Alone Is Not Enough

**Domain:** Accessibility

**Red/green distinctions are invisible to 8% of users.** Always pair color with a second signal: an icon, a label, a pattern, or a shape. This applies to charts, status indicators, form errors, and any state communicated purely through hue.

[View card →](https://launchyourvibe.live/card/a-06)

## A-07 — Support Text Resize Up to 200%

**Domain:** Accessibility

**Low-vision users regularly set system font size to 150–200%.** Use relative units (rem, em): never px for font sizes. Test by bumping browser font size to 200% and checking for content loss, overflow, or broken layouts. Mobile: respect system dynamic type settings.

[View card →](https://launchyourvibe.live/card/a-07)

## A-08 — Respect Reduced Motion Preferences

**Domain:** Accessibility

**Parallax, auto-playing carousels, and screen-wide transitions can trigger vestibular disorders.** Check `prefers-reduced-motion` and remove or minimize non-essential animation. Keep functional transitions (loading, focus)...eliminate decorative ones.

[View card →](https://launchyourvibe.live/card/a-08)

## A-09 — Labels Always Visible: Never Placeholder-Only

**Domain:** Accessibility

**Placeholders vanish when users start typing.** This breaks cognitive load for anyone who forgets what a field was, and breaks screen readers entirely. Use a persistent `<label>` element for every input. Placeholder text is fine for examples: not for labels.

[View card →](https://launchyourvibe.live/card/a-09)

## A-10 — Link Errors to Their Fields Programmatically

**Domain:** Accessibility

**Screen readers don't infer visual proximity.** Use `aria-describedby` to link the error message to its input, and `role="alert"` so it's announced immediately when it appears. `aria-invalid="true"` also signals the field state.

[View card →](https://launchyourvibe.live/card/a-10)

## A-11 — Skip Navigation Links Save Keyboard Users

**Domain:** Accessibility

**Keyboard users Tab through every nav item on every page load.** A skip link lets them jump directly to main content. Place it as the very first focusable element. Visually hide it until focused: don't remove it from the DOM or tab order.

[View card →](https://launchyourvibe.live/card/a-11)

## A-12 — Alt Text: Describe the Purpose, Not the Pixels

**Domain:** Accessibility

**Alt text should convey what the image communicates in context.** If the image is pure decoration, use an empty alt attribute (`alt=""`) so screen readers skip it. If it's a chart, describe the key insight: not the visual style.

[View card →](https://launchyourvibe.live/card/a-12)

## A-13 — DOM Order = Reading Order

**Domain:** Accessibility

**Screen readers follow the DOM: not what's visible on screen.** Using CSS `order`, `float`, or absolute positioning to rearrange visuals without reordering HTML creates a disjointed reading experience for keyboard and screen reader users.

[View card →](https://launchyourvibe.live/card/a-13)

## A-14 — Icon Buttons Need Accessible Names

**Domain:** Accessibility

**The accessible name is what screen readers announce.** For icon-only buttons the visual label is the icon: which is meaningless to AT. Pick the strategy that fits: `aria-label` for standalone icons, visually-hidden text when you need translatable strings, `aria-labelledby` when a visible label exists nearby.

[View card →](https://launchyourvibe.live/card/a-14)

## A-15 — WCAG Levels: A, AA, and AAA in Practice

**Domain:** Accessibility

**AA is the target for most products, and what most accessibility laws require.** AAA is aspirational and not required for entire sites. Start with AA conformance, document your approach, and layer in AAA where it meaningfully serves your users.

[View card →](https://launchyourvibe.live/card/a-15)

# Data

## D-01 — Bar = Compare. Line = Change Over Time.

**Domain:** Data

**The wrong chart type doesn't just look off: it misleads.** Use bars when comparing discrete values across categories. Use lines when showing how a single value changes continuously over time. Connecting discrete categories with a line implies continuity that doesn't exist.

[View card →](https://launchyourvibe.live/card/d-01)

## D-02 — Pie Charts: Part-to-Whole Only. Max 5 Slices.

**Domain:** Data

**Pie charts only answer one question: what share of the whole?** They require slices to sum to 100%. Beyond 5 slices, human perception breaks down: angles are harder to compare than lengths. Use a bar chart if you want comparison; a pie if you want composition.

[View card →](https://launchyourvibe.live/card/d-02)

## D-03 — Empty Chart States Are Not Optional

**Domain:** Data

**An empty chart with no explanation looks broken.** Design the zero state: explain why there's no data, tell users what action produces data, and consider showing a ghost/preview of what the chart will look like. Every chart needs a zero state, a loading state, and an error state.

[View card →](https://launchyourvibe.live/card/d-03)

## D-04 — Axis Labels and Units Must Always Be Visible

**Domain:** Data

**A chart without axis labels is a Rorschach test.** Every axis needs a label and a unit. "Revenue" without "$" or "K" forces users to guess the scale. Never rely on tooltips alone: they're invisible on mobile and require interaction to reveal basic context.

[View card →](https://launchyourvibe.live/card/d-04)

## D-05 — Small Multiples Beat One Crowded Chart

**Domain:** Data

**When one chart gets more than 4–5 series, everything competes.** Small multiples repeat the same chart structure for each category, letting users see patterns across dimensions at a glance. Same scale, same axes: shape differences become immediately readable.

[View card →](https://launchyourvibe.live/card/d-05)

## D-06 — Use Accessible Palettes in Data Visualization

**Domain:** Data

**Never rely on red vs. green to distinguish data series.** Use palettes designed for colorblind users (IBM Carbon, ColorBrewer, Tableau colorblind). Pair color differences with shape, texture, or direct labeling so the chart works without color at all.

[View card →](https://launchyourvibe.live/card/d-06)

## D-07 — Tables for Lookup. Charts for Patterns.

**Domain:** Data

**Charts reveal patterns; tables reveal values.** If a user needs to look up a specific number, a table serves them better than a chart. If they need to understand a trend, distribution, or comparison across categories, a chart does what a table can't.

[View card →](https://launchyourvibe.live/card/d-07)

## D-08 — Sparklines: Trend at a Glance

**Domain:** Data

**Sparklines pack trend context into a single row.** They're not for precise reading: they're for direction and shape at a glance. Pair them with a KPI value. Omit axis labels; the shape is the message. Perfect for dashboards with many metrics in limited space.

[View card →](https://launchyourvibe.live/card/d-08)

## D-09 — Reduce Data Density on Mobile

**Domain:** Data

**Mobile screens are too narrow for complex chart layouts.** Reduce the number of data points, consolidate time periods (months → quarters), increase label size, and favor horizontal bar charts over vertical ones where space is constrained. Link to a fuller view if detail matters.

[View card →](https://launchyourvibe.live/card/d-09)

## D-10 — Chart Tooltips: Detail on Demand

**Domain:** Data

**Tooltips layer precise values onto a chart without cluttering it.** Don't rely on them as the only access to important data: mobile users must tap to trigger them, and they're invisible until interaction. Design for the chart to communicate its core message without tooltip dependency.

[View card →](https://launchyourvibe.live/card/d-10)

## D-11 — Bar Charts Start at Zero. Always.

**Domain:** Data

**Truncating a bar chart's y-axis turns minor differences into apparent crises.** Bar height encodes quantity: cutting the baseline misrepresents proportions. Line charts can use non-zero baselines to show variance; bar charts cannot. If differences are small, consider a line chart instead.

[View card →](https://launchyourvibe.live/card/d-11)

## D-12 — Donut Charts: Add a Summary KPI in the Center

**Domain:** Data

**The donut chart's hole is prime real estate.** Use it for the single most important number: total, percentage complete, or a key KPI. Without a center value, a donut chart is just a pie with a hole: the center makes it meaningfully different.

[View card →](https://launchyourvibe.live/card/d-12)

## D-13 — Stacked Bars Mislead Middle Segments

**Domain:** Data

**Stacked bars only allow accurate comparison of the bottom segment and the total.** Middle segments float on different baselines, making comparison nearly impossible. If comparing sub-categories matters, use grouped bars. Use stacked bars only when total and bottom segment are the story.

[View card →](https://launchyourvibe.live/card/d-13)

## D-14 — Layer Data: Summary First, Detail on Demand

**Domain:** Data

**Most users want the headline; a few want the footnotes.** Lead with the single most important number and its trend. Let users drill into breakdown views only if they choose. Showing everything at once creates dashboards that exhaust instead of inform.

[View card →](https://launchyourvibe.live/card/d-14)

## D-15 — Chart Titles State the Insight, Not the Subject

**Domain:** Data

**A subject title labels the chart. An insight title does the analysis for the reader.** Move the descriptive label to a subtitle. The title should complete the sentence: "The main thing this chart shows is ___." Users shouldn't have to read and interpret: they should arrive at the conclusion immediately.

[View card →](https://launchyourvibe.live/card/d-15)

# Security

## S-01 — Filter by User ID. Always.

**Domain:** Security

**Every user-specific fetch must filter by the authenticated user's ID.** Test it by logging in as User A and manually requesting User B's data. If you can see it, you have a problem. This isn't a platform feature you toggle on — it's a check you write and verify.

[View card →](https://launchyourvibe.live/card/s-01)

## S-02 — Use Supabase, Clerk, or Auth0.

**Domain:** Security

**Rolling your own session management is where breaches are born.** Use Supabase Auth, Clerk, or Auth0. They handle tokens, refresh, MFA, and OAuth so you don't have to — and they stay patched when new vulnerabilities emerge.

[View card →](https://launchyourvibe.live/card/s-02)

## S-03 — Hiding a Button Is Not Security.

**Domain:** Security

**Every protected action checks the session on the server before returning data.** UI-only access control is theater — a crafted request bypasses it in seconds. Hiding a button is not access control.

[View card →](https://launchyourvibe.live/card/s-03)

## S-04 — Client Code Is Public Code.

**Domain:** Security

**Anything shipped to the client is public.** API keys, service role keys, admin flags — none of it belongs in frontend code. If it's in your bundle, assume everyone can read it.

[View card →](https://launchyourvibe.live/card/s-04)

## S-05 — .env in Gitignore. Rotate if Exposed.

**Domain:** Security

**Committed secrets live in history forever even after deletion.** Gitignore .env and rotate anything that ever shipped. A deleted line in today's code doesn't erase yesterday's commit.

[View card →](https://launchyourvibe.live/card/s-05)

## S-06 — Parameterize Every Query.

**Domain:** Security

**Raw string concatenation in queries is how SQL injection happens.** Parameterized queries are non-negotiable — let the database engine separate data from instructions.

[View card →](https://launchyourvibe.live/card/s-06)

## S-07 — localStorage = Readable by Any Script.

**Domain:** Security

**JWTs stored in localStorage are readable by any script on the page.** httpOnly cookies are not. One XSS vulnerability with localStorage tokens = full account takeover.

[View card →](https://launchyourvibe.live/card/s-07)

## S-08 — Lock Out After 5–10 Failures.

**Domain:** Security

**Unlimited login attempts are a brute force welcome mat.** Throttle or lock after 5–10 failures. Add exponential backoff and alert on suspicious patterns.

[View card →](https://launchyourvibe.live/card/s-08)

## S-09 — Never Trust the Client.

**Domain:** Security

**Everything reaching the database is checked for type, length, and allowed values.** Client-side validation is UX convenience, not security — it can be bypassed with a single curl command.

[View card →](https://launchyourvibe.live/card/s-09)

## S-10 — User Content Is Untrusted HTML.

**Domain:** Security

**User-generated content rendered directly to the DOM is an XSS vector.** Escape or sanitize everything that came from a user before it touches the page.

[View card →](https://launchyourvibe.live/card/s-10)

## S-11 — Including Staging. No Exceptions.

**Domain:** Security

**HTTPS everywhere, always — no exceptions, including staging.** Let's Encrypt makes this free. There is no excuse — credentials and tokens travel in plaintext without it.

[View card →](https://launchyourvibe.live/card/s-11)

## S-12 — Search for key, secret, token.

**Domain:** Security

**Search your codebase for key, secret, token, password before every deploy.** One command, five minutes, no surprises. Make it part of your ship checklist.

[View card →](https://launchyourvibe.live/card/s-12)

## S-13 — Old Commits Keep Secrets Forever.

**Domain:** Security

**Before going public, run a secret scanner on your commit history.** You'd be surprised what's buried in old commits — deleted files don't delete the history.

[View card →](https://launchyourvibe.live/card/s-13)

## S-14 — npm audit Before Launch.

**Domain:** Security

**Run npm audit or equivalent before launch.** Known vulnerabilities in packages you didn't write are still your problem — transitive dependencies included.

[View card →](https://launchyourvibe.live/card/s-14)

## S-15 — Rotate First. Investigate Second.

**Domain:** Security

**The moment you suspect exposure, rotate first, investigate second.** Stop the bleeding before you figure out the wound. A compromised key still works until you revoke it.

[View card →](https://launchyourvibe.live/card/s-15)

# Privacy

## P-01 — Every Field Needs a Reason.

**Domain:** Privacy

**Data you never collected can't leak.** Every field in your schema should have a documented reason to exist. If you can't explain why you need it, don't collect it.

[View card →](https://launchyourvibe.live/card/p-01)

## P-02 — Policy = What You Actually Collect.

**Domain:** Privacy

**Your privacy policy must match the code, not your intentions.** It describes what you actually collect, not what you intended to. A lying policy is legally worse than none.

[View card →](https://launchyourvibe.live/card/p-02)

## P-03 — Pre-Checked Isn't Consent.

**Domain:** Privacy

**Email requires explicit opt-in.** Pre-checked boxes aren't consent. CAN-SPAM and GDPR both have teeth and neither cares that you're small.

[View card →](https://launchyourvibe.live/card/p-03)

## P-04 — Know Where Every Piece Lives.

**Domain:** Privacy

**Users can delete their data — you need to know where it all is first.** Know where every piece of user data lives before someone asks you to remove it. "I'm not sure" is not an answer.

[View card →](https://launchyourvibe.live/card/p-04)

## P-05 — Logs Are a Liability Too.

**Domain:** Privacy

**Don't log what you don't need.** Full user-agents, IP addresses, raw request bodies — if you're not actively using it, don't keep it. Logs are a liability too.

[View card →](https://launchyourvibe.live/card/p-05)

## P-06 — Know What You've Invited In.

**Domain:** Privacy

**Third-party scripts see everything on your page.** Every analytics tag, chat widget, and ad pixel has access to your DOM and potentially your users' data. Know what you've invited in.

[View card →](https://launchyourvibe.live/card/p-06)

## P-07 — Stolen Credentials Shouldn't Last Forever.

**Domain:** Privacy

**Sessions that never expire are stolen credentials that work forever.** Set a reasonable timeout and enforce it. Refresh tokens rotate; idle sessions die.

[View card →](https://launchyourvibe.live/card/p-07)

## P-08 — Never Plain Text in a Column.

**Domain:** Privacy

**Sensitive fields get encrypted or hashed at rest.** Passwords, tokens, anything personally identifiable — hashed or encrypted at rest. Never plain text in a column.

[View card →](https://launchyourvibe.live/card/p-08)

## P-09 — A Backup You've Never Restored Is a Guess.

**Domain:** Privacy

**Backups exist and are tested.** Know where your backups are and verify one actually works. A backup you've never restored is a guess.

[View card →](https://launchyourvibe.live/card/p-09)

## P-10 — Treat Every Repo As Public Tomorrow.

**Domain:** Privacy

**Private repos aren't security.** Treat every repo as if it could go public tomorrow. Private today doesn't mean private forever — misconfigured permissions, acquired companies, and leaked tokens happen.

[View card →](https://launchyourvibe.live/card/p-10)

## P-11 — No DROP or ALTER for Your App User.

**Domain:** Privacy

**Least privilege on database users.** Your app's database user shouldn't have DROP or ALTER permissions. Give it only what it needs to function — SELECT, INSERT, UPDATE, DELETE on specific tables.

[View card →](https://launchyourvibe.live/card/p-11)

## P-12 — Drop Unused Fields Before Launch.

**Domain:** Privacy

**Store the least data you can.** Drop unused fields before launch, not after a breach. Data minimization is a design decision, not a cleanup task.

[View card →](https://launchyourvibe.live/card/p-12)

## P-13 — Third Parties Belong in Your Policy.

**Domain:** Privacy

**Disclose what you share.** If data touches a third party — analytics, payment processor, email provider — your privacy policy says so explicitly. Name them, name the data, name the purpose.

[View card →](https://launchyourvibe.live/card/p-13)

## P-14 — Export, Correct, and Delete.

**Domain:** Privacy

**Give users control over their data.** Export, correction, and deletion aren't just legal requirements in some jurisdictions. They're what trustworthy products do.

[View card →](https://launchyourvibe.live/card/p-14)

## P-15 — Know Who to Notify Before It Happens.

**Domain:** Privacy

**Breach plan before you need one.** Know who you'd notify, in what order, within what timeframe. Figuring it out during an incident is too late.

[View card →](https://launchyourvibe.live/card/p-15)

# Install LaunchYourVibe Guardrails

Plain-language setup for vibe coders using Cursor. Takes about 5 minutes.

## What you got

- **Starter rules** — always-on guardrails (~28 highest-impact rules)
- **Domain packs** — optional rules by topic (enable what you need)
- **Ship-check skill** — run a full review before you ship
- **Cheat sheet** — all 120 cards in one searchable doc

## Cursor setup

1. Open your project in Cursor.
2. Copy the `cursor/rules/` folder from this kit into your project's `.cursor/rules/` directory.
   - Merge with existing rules if you already have some.
3. Copy `cursor/skills/launchyourvibe-ship-check/` into `.cursor/skills/launchyourvibe-ship-check/`.
4. In Cursor, confirm **launchyourvibe-starter** is enabled (always apply).
5. Optionally enable domain packs when you're working in that area — e.g. turn on **launchyourvibe-accessibility** while building forms.

## Using the ship-check skill

When you finish a feature, ask Cursor:

> Run a LaunchYourVibe ship check on [this screen / these files]

The skill walks the agent through your code against the full rule library.

## Other tools

The `portable/rules/` folder has plain Markdown copies without Cursor frontmatter.
Adapt them for Claude Code, Windsurf, Copilot, or AGENTS.md as needed.

## Learn the patterns

Browse the visual deck at https://launchyourvibe.live — click any card to flip it and see the pattern.

© UpStart Productions · https://launchyourvibe.live

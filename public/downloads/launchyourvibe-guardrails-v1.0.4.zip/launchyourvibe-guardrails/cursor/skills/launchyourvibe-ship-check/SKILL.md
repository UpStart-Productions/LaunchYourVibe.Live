---
name: launchyourvibe-ship-check
description: Review UI and app code against LaunchYourVibe reference standards (UX, accessibility, security, privacy). Use when the user asks for a vibe check, ship check, UX review, accessibility pass, or before shipping a feature.
disable-model-invocation: true
---

# LaunchYourVibe Ship Check

Run a structured review of the current feature or changed files against LaunchYourVibe standards.

## When to use

- User asks for a vibe check, ship check, or pre-ship review
- Before marking a UI feature, form flow, or auth/data feature complete
- After building empty states, charts, modals, or icon-button toolbars

## Procedure

1. Identify what was built (screens, components, API routes, forms, auth).
2. Read [reference.md](reference.md) for the full rule library — focus on domains relevant to the work.
3. Check the code against applicable rules. Flag violations with:
   - Card ID (e.g. A-04)
   - What's wrong
   - Concrete fix
   - Permalink to the card
4. Prioritize: accessibility and security issues first, then UX polish.
5. End with a short pass/fail summary and a numbered fix list.

## Output format

```markdown
## LaunchYourVibe Ship Check

**Scope:** [what you reviewed]

### Issues
1. **[A-04] Icon delete button** — missing aria-label. Fix: add aria-label="Delete item". Reference: https://launchyourvibe.live/card/a-04

### Passed
- N-01 empty state includes headline and CTA

**Verdict:** Needs fixes (1 critical, 0 moderate)
```

## Notes

- Do not invent rules not in reference.md.
- If unsure, cite the closest card and explain the gap.
- Link every issue to its card permalink.

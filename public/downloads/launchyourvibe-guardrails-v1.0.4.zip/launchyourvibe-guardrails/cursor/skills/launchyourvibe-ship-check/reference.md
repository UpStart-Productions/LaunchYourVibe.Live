# LaunchYourVibe Rule Reference

Full library (119 cards). Generated from https://launchyourvibe.live.

Each rule includes a **When** trigger, the rule text, and a permalink to the visual card.

### A-01 — Contrast Ratios: AA vs AAA

**When:** Working on contrast ratios: aa vs aaa (Accessibility)

**Rule:** **AA is the legal baseline; AAA is the gold standard.** Body text needs 4.5:1. Large text (18pt+ or 14pt+ bold) needs 3:1. UI components and icons need 3:1 against adjacent colors. Test with a real contrast checker: eyeballing fails.

**Reference:** https://launchyourvibe.live/card/a-01

### A-02 — Touch Target Minimum Sizes

**When:** Working on touch target minimum sizes (Accessibility)

**Rule:** **A visually small element can still have a large hit area.** iOS requires 44×44pt, Android recommends 48×48dp. Use padding to expand the tap zone without changing visual size. Crowded targets need 8pt spacing between them.

**Reference:** https://launchyourvibe.live/card/a-02

### A-03 — Focus Indicators Must Be Visible

**When:** Working on focus indicators must be visible (Accessibility)

**Rule:** **Keyboard users navigate entirely by focus ring.** Never suppress it with `outline: none` without a custom replacement. Focus must meet 3:1 contrast against adjacent colors. Use `:focus-visible` to show it only for keyboard, not mouse.

**Reference:** https://launchyourvibe.live/card/a-03

### A-04 — Every Interactive Element Needs a Label

**When:** Creating icon-only buttons or controls with no visible text label

**Rule:** **Icon buttons are invisible to screen readers without labels.** Add `aria-label` to every icon-only button. Use `aria-labelledby` when a visible label exists nearby. The label should describe the action, not the icon.

**Reference:** https://launchyourvibe.live/card/a-04

### A-05 — Semantic HTML: Structure Is Meaning

**When:** Choosing HTML elements (buttons, links, headings, landmarks) for structure

**Rule:** **HTML elements carry meaning that assistive tech relies on.** Use `<button>` for actions, `<a>` for navigation, and heading tags in sequential order. Screen readers use landmark elements (`main`, `nav`, `aside`) to let users jump between page sections.

**Reference:** https://launchyourvibe.live/card/a-05

### A-06 — Color Alone Is Not Enough

**When:** Working on color alone is not enough (Accessibility)

**Rule:** **Red/green distinctions are invisible to 8% of users.** Always pair color with a second signal: an icon, a label, a pattern, or a shape. This applies to charts, status indicators, form errors, and any state communicated purely through hue.

**Reference:** https://launchyourvibe.live/card/a-06

### A-07 — Support Text Resize Up to 200%

**When:** Working on support text resize up to 200% (Accessibility)

**Rule:** **Low-vision users regularly set system font size to 150–200%.** Use relative units (rem, em): never px for font sizes. Test by bumping browser font size to 200% and checking for content loss, overflow, or broken layouts. Mobile: respect system dynamic type settings.

**Reference:** https://launchyourvibe.live/card/a-07

### A-08 — Respect Reduced Motion Preferences

**When:** Working on respect reduced motion preferences (Accessibility)

**Rule:** **Parallax, auto-playing carousels, and screen-wide transitions can trigger vestibular disorders.** Check `prefers-reduced-motion` and remove or minimize non-essential animation. Keep functional transitions (loading, focus)...eliminate decorative ones.

**Reference:** https://launchyourvibe.live/card/a-08

### A-09 — Labels Always Visible: Never Placeholder-Only

**When:** Adding form inputs, search fields, or any text field

**Rule:** **Placeholders vanish when users start typing.** This breaks cognitive load for anyone who forgets what a field was, and breaks screen readers entirely. Use a persistent `<label>` element for every input. Placeholder text is fine for examples: not for labels.

**Reference:** https://launchyourvibe.live/card/a-09

### A-10 — Link Errors to Their Fields Programmatically

**When:** Showing validation errors, helper text, or inline field feedback

**Rule:** **Screen readers don't infer visual proximity.** Use `aria-describedby` to link the error message to its input, and `role="alert"` so it's announced immediately when it appears. `aria-invalid="true"` also signals the field state.

**Reference:** https://launchyourvibe.live/card/a-10

### A-11 — Skip Navigation Links Save Keyboard Users

**When:** Working on skip navigation links save keyboard users (Accessibility)

**Rule:** **Keyboard users Tab through every nav item on every page load.** A skip link lets them jump directly to main content. Place it as the very first focusable element. Visually hide it until focused: don't remove it from the DOM or tab order.

**Reference:** https://launchyourvibe.live/card/a-11

### A-12 — Alt Text: Describe the Purpose, Not the Pixels

**When:** Working on alt text: describe the purpose, not the pixels (Accessibility)

**Rule:** **Alt text should convey what the image communicates in context.** If the image is pure decoration, use an empty alt attribute (`alt=""`) so screen readers skip it. If it's a chart, describe the key insight: not the visual style.

**Reference:** https://launchyourvibe.live/card/a-12

### A-13 — DOM Order = Reading Order

**When:** Working on dom order = reading order (Accessibility)

**Rule:** **Screen readers follow the DOM: not what's visible on screen.** Using CSS `order`, `float`, or absolute positioning to rearrange visuals without reordering HTML creates a disjointed reading experience for keyboard and screen reader users.

**Reference:** https://launchyourvibe.live/card/a-13

### A-14 — Icon Buttons Need Accessible Names

**When:** Naming interactive elements for screen readers (buttons, links, inputs)

**Rule:** **The accessible name is what screen readers announce.** For icon-only buttons the visual label is the icon: which is meaningless to AT. Pick the strategy that fits: `aria-label` for standalone icons, visually-hidden text when you need translatable strings, `aria-labelledby` when a visible label exists nearby.

**Reference:** https://launchyourvibe.live/card/a-14

### A-15 — WCAG Levels: A, AA, and AAA in Practice

**When:** Working on wcag levels: a, aa, and aaa in practice (Accessibility)

**Rule:** **AA is the target for most products, and what most accessibility laws require.** AAA is aspirational and not required for entire sites. Start with AA conformance, document your approach, and layer in AAA where it meaningfully serves your users.

**Reference:** https://launchyourvibe.live/card/a-15

### C-01 — Modal → Desktop Bottom Sheet → Mobile

**When:** Building primary/secondary actions or button hierarchies

**Rule:** **Modals trap thumbs.** On mobile, a centered dialog requires two-handed use. A bottom sheet rises from where thumbs already live. Same intent. Opposite ergonomics.

**Reference:** https://launchyourvibe.live/card/c-01

### C-02 — Tab Bar → Mobile Sidebar → Desktop

**When:** Working on tab bar → mobile sidebar → desktop (Components)

**Rule:** **Thumb reach dictates nav placement.** Bottom tabs stay in the natural grip zone on mobile. Sidebars use the screen width that desktop has to spare. Never swap them.

**Reference:** https://launchyourvibe.live/card/c-02

### C-03 — Forms Are Always Single Column on Mobile

**When:** Working on forms are always single column on mobile (Components)

**Rule:** **Two columns on mobile means two columns of tiny inputs.** Users skip fields accidentally and make more errors. Single column, full width. One field, one decision at a time.

**Reference:** https://launchyourvibe.live/card/c-03

### C-04 — Toggle = Immediate. Checkbox = On Submit.

**When:** Working on toggle = immediate. checkbox = on submit. (Components)

**Rule:** **Toggles are instant actions. Checkboxes are selection within a form.** If the setting takes effect the moment you flip it (like dark mode), use a toggle. If it's part of a group submitted together, use checkboxes.

**Reference:** https://launchyourvibe.live/card/c-04

### C-05 — Cards for Browse. Lists for Scan.

**When:** Working on cards for browse. lists for scan. (Components)

**Rule:** **Cards invite exploration; lists support comparison.** Use cards when each item has rich media or requires its own visual weight. Use lists when users are scanning for a specific item quickly.

**Reference:** https://launchyourvibe.live/card/c-05

### C-06 — Dropdowns on Mobile: Use Native or Bottom Sheet

**When:** Working on dropdowns on mobile: use native or bottom sheet (Components)

**Rule:** **Custom dropdowns fight the OS.** Native selects trigger the platform's built-in scroll picker: optimized for touch. Only build custom when the native control genuinely fails the need.

**Reference:** https://launchyourvibe.live/card/c-06

### C-07 — FAB = One Primary Action. One.

**When:** Working on fab = one primary action. one. (Components)

**Rule:** **The FAB is the most prominent tap target on screen.** It implies "this is the thing you do most." If you can't name that one action, the FAB isn't the right pattern.

**Reference:** https://launchyourvibe.live/card/c-07

### C-08 — Chips: Filter or Select, Not Both at Once

**When:** Working on chips: filter or select, not both at once (Components)

**Rule:** **Chips have two distinct jobs: filtering and input.** Don't mix them on the same surface. Filter chips are toggles. Input chips represent values the user has added. Styling should signal the difference.

**Reference:** https://launchyourvibe.live/card/c-08

### C-09 — Accordions Hide Content. Use Them Intentionally.

**When:** Working on accordions hide content. use them intentionally. (Components)

**Rule:** **Accordions create extra work for the user.** Every collapsed section is a barrier. Use them when the content is genuinely optional: not to make a page feel shorter while hiding required reading.

**Reference:** https://launchyourvibe.live/card/c-09

### C-10 — Date Pickers: Match the Date Type

**When:** Working on date pickers: match the date type (Components)

**Rule:** **There is no universal date picker.** Picking a birthday is a different task than scheduling a meeting. The interface should match the cognitive model: not force a calendar view on every date type.

**Reference:** https://launchyourvibe.live/card/c-10

### C-11 — 4 Alert Levels. Don't Cry Wolf.

**When:** Showing alerts, banners, toasts, or status messages

**Rule:** **Every alert in red trains users to ignore red.** Reserve error alerts for actual errors. Info banners for context. If everything is urgent, nothing is. Overused alerts become wallpaper.

**Reference:** https://launchyourvibe.live/card/c-11

### C-12 — Search Placement Signals Its Importance

**When:** Working on search placement signals its importance (Components)

**Rule:** **If search is how most users navigate, it belongs at the top: always visible.** If it's a power-user feature, tuck it in nav. Never make it a modal activation or a tiny corner icon on search-first apps.

**Reference:** https://launchyourvibe.live/card/c-12

### C-13 — Steppers for Small Ranges. Input for Large.

**When:** Working on steppers for small ranges. input for large. (Components)

**Rule:** **Steppers work for small, bounded quantities.** If someone might want 500 of something, don't make them tap 499 times. Offer a direct input. Steppers should cover ranges users reach in under 10 taps.

**Reference:** https://launchyourvibe.live/card/c-13

### C-14 — Tooltips Are for Desktop Power Users

**When:** Relying on tooltips to explain how a control works

**Rule:** **If users need a tooltip to use a feature, the feature needs better labeling.** Tooltips are bonus context for experienced users: not a substitute for clear UI copy. And they don't exist on touch screens.

**Reference:** https://launchyourvibe.live/card/c-14

### C-15 — Infinite Scroll for Browse. Pagination for Find.

**When:** Working on infinite scroll for browse. pagination for find. (Components)

**Rule:** **Infinite scroll removes the user's sense of location.** If they need to return to a specific item or share a result, pagination gives them an address. Endless scroll is for consuming, not finding.

**Reference:** https://launchyourvibe.live/card/c-15

### D-01 — Bar = Compare. Line = Change Over Time.

**When:** Working on bar = compare. line = change over time. (Data)

**Rule:** **The wrong chart type doesn't just look off: it misleads.** Use bars when comparing discrete values across categories. Use lines when showing how a single value changes continuously over time. Connecting discrete categories with a line implies continuity that doesn't exist.

**Reference:** https://launchyourvibe.live/card/d-01

### D-02 — Pie Charts: Part-to-Whole Only. Max 5 Slices.

**When:** Working on pie charts: part-to-whole only. max 5 slices. (Data)

**Rule:** **Pie charts only answer one question: what share of the whole?** They require slices to sum to 100%. Beyond 5 slices, human perception breaks down: angles are harder to compare than lengths. Use a bar chart if you want comparison; a pie if you want composition.

**Reference:** https://launchyourvibe.live/card/d-02

### D-03 — Empty Chart States Are Not Optional

**When:** Working on empty chart states are not optional (Data)

**Rule:** **An empty chart with no explanation looks broken.** Design the zero state: explain why there's no data, tell users what action produces data, and consider showing a ghost/preview of what the chart will look like. Every chart needs a zero state, a loading state, and an error state.

**Reference:** https://launchyourvibe.live/card/d-03

### D-04 — Axis Labels and Units Must Always Be Visible

**When:** Building charts or graphs with axes

**Rule:** **A chart without axis labels is a Rorschach test.** Every axis needs a label and a unit. "Revenue" without "$" or "K" forces users to guess the scale. Never rely on tooltips alone: they're invisible on mobile and require interaction to reveal basic context.

**Reference:** https://launchyourvibe.live/card/d-04

### D-05 — Small Multiples Beat One Crowded Chart

**When:** Working on small multiples beat one crowded chart (Data)

**Rule:** **When one chart gets more than 4–5 series, everything competes.** Small multiples repeat the same chart structure for each category, letting users see patterns across dimensions at a glance. Same scale, same axes: shape differences become immediately readable.

**Reference:** https://launchyourvibe.live/card/d-05

### D-06 — Use Accessible Palettes in Data Visualization

**When:** Working on use accessible palettes in data visualization (Data)

**Rule:** **Never rely on red vs. green to distinguish data series.** Use palettes designed for colorblind users (IBM Carbon, ColorBrewer, Tableau colorblind). Pair color differences with shape, texture, or direct labeling so the chart works without color at all.

**Reference:** https://launchyourvibe.live/card/d-06

### D-07 — Tables for Lookup. Charts for Patterns.

**When:** Choosing between a chart and a table for numeric data

**Rule:** **Charts reveal patterns; tables reveal values.** If a user needs to look up a specific number, a table serves them better than a chart. If they need to understand a trend, distribution, or comparison across categories, a chart does what a table can't.

**Reference:** https://launchyourvibe.live/card/d-07

### D-08 — Sparklines: Trend at a Glance

**When:** Working on sparklines: trend at a glance (Data)

**Rule:** **Sparklines pack trend context into a single row.** They're not for precise reading: they're for direction and shape at a glance. Pair them with a KPI value. Omit axis labels; the shape is the message. Perfect for dashboards with many metrics in limited space.

**Reference:** https://launchyourvibe.live/card/d-08

### D-09 — Reduce Data Density on Mobile

**When:** Working on reduce data density on mobile (Data)

**Rule:** **Mobile screens are too narrow for complex chart layouts.** Reduce the number of data points, consolidate time periods (months → quarters), increase label size, and favor horizontal bar charts over vertical ones where space is constrained. Link to a fuller view if detail matters.

**Reference:** https://launchyourvibe.live/card/d-09

### D-10 — Chart Tooltips: Detail on Demand

**When:** Working on chart tooltips: detail on demand (Data)

**Rule:** **Tooltips layer precise values onto a chart without cluttering it.** Don't rely on them as the only access to important data: mobile users must tap to trigger them, and they're invisible until interaction. Design for the chart to communicate its core message without tooltip dependency.

**Reference:** https://launchyourvibe.live/card/d-10

### D-11 — Bar Charts Start at Zero. Always.

**When:** Working on bar charts start at zero. always. (Data)

**Rule:** **Truncating a bar chart's y-axis turns minor differences into apparent crises.** Bar height encodes quantity: cutting the baseline misrepresents proportions. Line charts can use non-zero baselines to show variance; bar charts cannot. If differences are small, consider a line chart instead.

**Reference:** https://launchyourvibe.live/card/d-11

### D-12 — Donut Charts: Add a Summary KPI in the Center

**When:** Working on donut charts: add a summary kpi in the center (Data)

**Rule:** **The donut chart's hole is prime real estate.** Use it for the single most important number: total, percentage complete, or a key KPI. Without a center value, a donut chart is just a pie with a hole: the center makes it meaningfully different.

**Reference:** https://launchyourvibe.live/card/d-12

### D-13 — Stacked Bars Mislead Middle Segments

**When:** Working on stacked bars mislead middle segments (Data)

**Rule:** **Stacked bars only allow accurate comparison of the bottom segment and the total.** Middle segments float on different baselines, making comparison nearly impossible. If comparing sub-categories matters, use grouped bars. Use stacked bars only when total and bottom segment are the story.

**Reference:** https://launchyourvibe.live/card/d-13

### D-14 — Layer Data: Summary First, Detail on Demand

**When:** Working on layer data: summary first, detail on demand (Data)

**Rule:** **Most users want the headline; a few want the footnotes.** Lead with the single most important number and its trend. Let users drill into breakdown views only if they choose. Showing everything at once creates dashboards that exhaust instead of inform.

**Reference:** https://launchyourvibe.live/card/d-14

### D-15 — Chart Titles State the Insight, Not the Subject

**When:** Working on chart titles state the insight, not the subject (Data)

**Rule:** **A subject title labels the chart. An insight title does the analysis for the reader.** Move the descriptive label to a subtitle. The title should complete the sentence: "The main thing this chart shows is ___." Users shouldn't have to read and interpret: they should arrive at the conclusion immediately.

**Reference:** https://launchyourvibe.live/card/d-15

### I-01 — Every Button Needs 4 States.

**When:** Working on every button needs 4 states. (Interaction)

**Rule:** **Missing a state isn't neutral.** No disabled state feels broken when nothing happens. Each state signals what's possible right now.

**Reference:** https://launchyourvibe.live/card/i-01

### I-02 — Error Messages: Say What + Why + Fix

**When:** Designing click/tap targets, buttons, or touch-friendly controls

**Rule:** **What happened. Why. What to do.** Three sentences max. Plain language. No stack traces. Never blame the user.

**Reference:** https://launchyourvibe.live/card/i-02

### I-03 — Loading: Match the Wait to the Pattern

**When:** Loading data, fetching content, or waiting on async operations

**Rule:** **Blank screens feel broken; spinners feel slow.** Use skeleton loaders for content-heavy loads. Spinners for <2s actions. Progress bars when the user needs to know how long.

**Reference:** https://launchyourvibe.live/card/i-03

### I-04 — Destructive Actions Need Friction: On Purpose

**When:** Working on destructive actions need friction: on purpose (Interaction)

**Rule:** **Make the danger legible.** Red button, explicit label, and a cost statement. "Are you sure?" without consequences doesn't create real friction: specifics do.

**Reference:** https://launchyourvibe.live/card/i-04

### I-05 — Success Is a Moment. Mark It.

**When:** Working on success is a moment. mark it. (Interaction)

**Rule:** **Silence after a successful action breeds doubt.** Confirm what happened, to whom, and what comes next. The user's mental model needs closure.

**Reference:** https://launchyourvibe.live/card/i-05

### I-06 — Toast = Info. Dialog = Decision.

**When:** Working on toast = info. dialog = decision. (Interaction)

**Rule:** **Dialogs steal focus because they have to.** If the user can ignore it, use a toast. If they must choose, use a dialog. Never use a dialog to say something they don't need to act on.

**Reference:** https://launchyourvibe.live/card/i-06

### I-07 — Validate on Blur, Not on Keystroke

**When:** Working on validate on blur, not on keystroke (Interaction)

**Rule:** **Showing errors while someone is mid-thought is hostile.** Wait for blur (field exit) to validate. Only re-validate on keystroke after the first error appears. Never on every character.

**Reference:** https://launchyourvibe.live/card/i-07

### I-08 — Optimistic UI: Show Success First

**When:** Working on optimistic ui: show success first (Interaction)

**Rule:** **Most requests succeed.** Assume success, update the UI immediately, sync in the background. Roll back only on actual failure. The app feels instant even when it isn't.

**Reference:** https://launchyourvibe.live/card/i-08

### I-09 — Undo Beats Confirm Dialogs

**When:** Working on undo beats confirm dialogs (Interaction)

**Rule:** **Confirms interrupt flow. Undo restores agency.** Let users act immediately, then give them a short window to reverse it. They feel more in control, not less.

**Reference:** https://launchyourvibe.live/card/i-09

### I-10 — Every Tap Needs Immediate Feedback

**When:** Working on every tap needs immediate feedback (Interaction)

**Rule:** **Without feedback, users tap twice.** Response within 100ms feels instantaneous. 100–300ms feels fast. Beyond 300ms, users start to doubt. Give visual feedback first, everything else second.

**Reference:** https://launchyourvibe.live/card/i-10

### I-11 — Progress: Show Where They Are

**When:** Working on progress: show where they are (Interaction)

**Rule:** **Progress without context is just anxiety.** Show step number, percentage, or time estimate. Giving users a frame of reference reduces perceived wait time by 40%.

**Reference:** https://launchyourvibe.live/card/i-11

### I-12 — Hover Actions Don't Exist on Mobile

**When:** Adding hover-only actions, tooltips, or menus that reveal on pointer hover

**Rule:** **Touch has no cursor.** Any interaction hidden behind hover is invisible on mobile. If your content needs additional actions, make them visible, not discoverable via pointer proximity.

**Reference:** https://launchyourvibe.live/card/i-12

### I-13 — Disabled Means "Not Yet": Explain Why

**When:** Working on disabled means "not yet": explain why (Interaction)

**Rule:** **A grayed button with no explanation creates confusion.** Tell users what they're missing. The block becomes a guide, and prevents them from abandoning the form in frustration.

**Reference:** https://launchyourvibe.live/card/i-13

### I-14 — Swipe Actions Need Visual Teaching

**When:** Working on swipe actions need visual teaching (Interaction)

**Rule:** **Gestures are invisible until taught.** On first use, animate a partial swipe. Use destructive actions only on one side: left for danger is a convention users already know.

**Reference:** https://launchyourvibe.live/card/i-14

### I-15 — Right Keyboard for Every Input

**When:** Adding phone, email, number, or other typed input fields

**Rule:** **The wrong keyboard is a tiny betrayal of trust.** A number pad for phone numbers, @ key for emails: set inputmode or type correctly and the keyboard is already optimized.

**Reference:** https://launchyourvibe.live/card/i-15

### N-01 — Empty States Are Not Optional

**When:** Rendering empty lists, dashboards, inboxes, or zero-result states

**Rule:** **Every empty screen is a first impression of a feature.** Tell them what belongs here, why it's empty, and exactly what to do next. Icon + headline + CTA. Three elements, every time.

**Reference:** https://launchyourvibe.live/card/n-01

### N-02 — New Screen or Overlay? Ask About Context.

**When:** Choosing between a modal/dialog and a new page or route

**Rule:** **The choice is really about whether the user is leaving their current task or pausing it.** If they're leaving, push a new screen. If they're pausing, use an overlay that lets them see and return to where they came from.

**Reference:** https://launchyourvibe.live/card/n-02

### N-03 — Back Should Go Back. Not Somewhere Weird.

**When:** Working on back should go back. not somewhere weird. (Navigation)

**Rule:** **Back is the most-used navigation action.** When it teleports users somewhere unexpected, they lose their mental map of the app. Maintain a proper back stack: always. Test deep links specifically.

**Reference:** https://launchyourvibe.live/card/n-03

### N-04 — Delay Onboarding Until Users Need It

**When:** Working on delay onboarding until users need it (Navigation)

**Rule:** **Users skip onboarding they haven't earned yet.** Show guidance at the moment it becomes relevant: not before. Empty states, coach marks, and contextual tooltips teach while users are actually doing the thing.

**Reference:** https://launchyourvibe.live/card/n-04

### N-05 — Every Screen Should Be Deep-Linkable

**When:** Working on every screen should be deep-linkable (Navigation)

**Rule:** **If you can't link to it, you can't share it, bookmark it, or return to it.** Every meaningful screen in your app should have a URL that restores its full state. This also forces you to design URL-safe navigation.

**Reference:** https://launchyourvibe.live/card/n-05

### N-06 — Tab Bar: 3–5 Items. No More.

**When:** Working on tab bar: 3–5 items. no more. (Navigation)

**Rule:** **Beyond 5 tabs, labels disappear and icons carry everything.** If you have 6+ destinations, restructure the IA: nest them, or use a different nav pattern. Tab bars are for top-level, equal-weight destinations.

**Reference:** https://launchyourvibe.live/card/n-06

### N-07 — Breadcrumbs for Deep Hierarchies Only

**When:** Working on breadcrumbs for deep hierarchies only (Navigation)

**Rule:** **Breadcrumbs tell you where you are in a hierarchy: not history.** They're a map, not a back button. On mobile, replace with just a Back label showing the parent's name.

**Reference:** https://launchyourvibe.live/card/n-07

### N-08 — Settings = Profile Menu. Not a Main Tab.

**When:** Working on settings = profile menu. not a main tab. (Navigation)

**Rule:** **Settings is infrequently used.** Reserve primary tab real estate for actions users take every session. Settings lives naturally under the profile: where every mobile convention has trained users to look.

**Reference:** https://launchyourvibe.live/card/n-08

### N-09 — Delay Login Until the User Has a Reason

**When:** Working on delay login until the user has a reason (Navigation)

**Rule:** **Login walls at launch filter out users who haven't seen the value yet.** Let users experience the app before asking for commitment. Gate only actions that genuinely require an account.

**Reference:** https://launchyourvibe.live/card/n-09

### N-10 — Gestures Must Be Taught or Discoverable

**When:** Working on gestures must be taught or discoverable (Navigation)

**Rule:** **Gestures are invisible: they don't announce themselves.** Animate a partial gesture on first load, show a hint overlay, or reveal a "Did you know?" prompt. Never rely on discoverability alone for critical actions.

**Reference:** https://launchyourvibe.live/card/n-10

### N-11 — Ask for Notifications After Showing Their Value

**When:** Working on ask for notifications after showing their value (Navigation)

**Rule:** **Permission prompts fail when the user has no context for what they're agreeing to.** Link the ask to a specific action the user just took. The value exchange is clear, and they're far more likely to say yes.

**Reference:** https://launchyourvibe.live/card/n-11

### N-12 — Design the Exit: Offboarding Matters

**When:** Working on design the exit: offboarding matters (Navigation)

**Rule:** **How users leave shapes how they remember you.** Dark patterns at offboarding (roach motel UX) create resentment and reviews. A clean, honest exit is a final brand impression, and sometimes brings people back.

**Reference:** https://launchyourvibe.live/card/n-12

### N-13 — Error Screens Need a Path Forward

**When:** Working on error screens need a path forward (Navigation)

**Rule:** **Dead ends destroy trust.** Every error screen needs at minimum: what happened (briefly), and a clear path forward. A search field is a bonus. Never leave the user with only a browser back button.

**Reference:** https://launchyourvibe.live/card/n-13

### N-14 — Primary Actions Don't Belong Below the Fold

**When:** Working on primary actions don't belong below the fold (Navigation)

**Rule:** **The fold is not dead.** On small screens, most users never scroll. Put the primary CTA in the viewport on load. Everything else can follow: but the first action the user should take must be immediately visible.

**Reference:** https://launchyourvibe.live/card/n-14

### N-15 — Preserve State When Users Leave and Return

**When:** Working on preserve state when users leave and return (Navigation)

**Rule:** **Users don't live inside your app.** They switch apps, get interrupted, background it. Persist form data, scroll position, and filter state. Losing work is one of the fastest ways to lose users permanently.

**Reference:** https://launchyourvibe.live/card/n-15

### P-01 — Every Field Needs a Reason.

**When:** Designing forms, schemas, or data collection flows

**Rule:** **Data you never collected can't leak.** Every field in your schema should have a documented reason to exist. If you can't explain why you need it, don't collect it.

**Reference:** https://launchyourvibe.live/card/p-01

### P-02 — Policy = What You Actually Collect.

**When:** Working on policy = what you actually collect. (Privacy)

**Rule:** **Your privacy policy must match the code, not your intentions.** It describes what you actually collect, not what you intended to. A lying policy is legally worse than none.

**Reference:** https://launchyourvibe.live/card/p-02

### P-03 — Pre-Checked Isn't Consent.

**When:** Email signup, newsletters, or marketing opt-in flows

**Rule:** **Email requires explicit opt-in.** Pre-checked boxes aren't consent. CAN-SPAM and GDPR both have teeth and neither cares that you're small.

**Reference:** https://launchyourvibe.live/card/p-03

### P-04 — Know Where Every Piece Lives.

**When:** Working on know where every piece lives. (Privacy)

**Rule:** **Users can delete their data — you need to know where it all is first.** Know where every piece of user data lives before someone asks you to remove it. "I'm not sure" is not an answer.

**Reference:** https://launchyourvibe.live/card/p-04

### P-05 — Logs Are a Liability Too.

**When:** Working on logs are a liability too. (Privacy)

**Rule:** **Don't log what you don't need.** Full user-agents, IP addresses, raw request bodies — if you're not actively using it, don't keep it. Logs are a liability too.

**Reference:** https://launchyourvibe.live/card/p-05

### P-06 — Know What You've Invited In.

**When:** Working on know what you've invited in. (Privacy)

**Rule:** **Third-party scripts see everything on your page.** Every analytics tag, chat widget, and ad pixel has access to your DOM and potentially your users' data. Know what you've invited in.

**Reference:** https://launchyourvibe.live/card/p-06

### P-07 — Stolen Credentials Shouldn't Last Forever.

**When:** Working on stolen credentials shouldn't last forever. (Privacy)

**Rule:** **Sessions that never expire are stolen credentials that work forever.** Set a reasonable timeout and enforce it. Refresh tokens rotate; idle sessions die.

**Reference:** https://launchyourvibe.live/card/p-07

### P-08 — Never Plain Text in a Column.

**When:** Storing passwords, tokens, or PII in a database

**Rule:** **Sensitive fields get encrypted or hashed at rest.** Passwords, tokens, anything personally identifiable — hashed or encrypted at rest. Never plain text in a column.

**Reference:** https://launchyourvibe.live/card/p-08

### P-09 — A Backup You've Never Restored Is a Guess.

**When:** Working on a backup you've never restored is a guess. (Privacy)

**Rule:** **Backups exist and are tested.** Know where your backups are and verify one actually works. A backup you've never restored is a guess.

**Reference:** https://launchyourvibe.live/card/p-09

### P-10 — Treat Every Repo As Public Tomorrow.

**When:** Working on treat every repo as public tomorrow. (Privacy)

**Rule:** **Private repos aren't security.** Treat every repo as if it could go public tomorrow. Private today doesn't mean private forever — misconfigured permissions, acquired companies, and leaked tokens happen.

**Reference:** https://launchyourvibe.live/card/p-10

### P-11 — No DROP or ALTER for Your App User.

**When:** Working on no drop or alter for your app user. (Privacy)

**Rule:** **Least privilege on database users.** Your app's database user shouldn't have DROP or ALTER permissions. Give it only what it needs to function — SELECT, INSERT, UPDATE, DELETE on specific tables.

**Reference:** https://launchyourvibe.live/card/p-11

### P-12 — Drop Unused Fields Before Launch.

**When:** Planning database columns, user profiles, or analytics fields

**Rule:** **Store the least data you can.** Drop unused fields before launch, not after a breach. Data minimization is a design decision, not a cleanup task.

**Reference:** https://launchyourvibe.live/card/p-12

### P-13 — Third Parties Belong in Your Policy.

**When:** Working on third parties belong in your policy. (Privacy)

**Rule:** **Disclose what you share.** If data touches a third party — analytics, payment processor, email provider — your privacy policy says so explicitly. Name them, name the data, name the purpose.

**Reference:** https://launchyourvibe.live/card/p-13

### P-14 — Export, Correct, and Delete.

**When:** Working on export, correct, and delete. (Privacy)

**Rule:** **Give users control over their data.** Export, correction, and deletion aren't just legal requirements in some jurisdictions. They're what trustworthy products do.

**Reference:** https://launchyourvibe.live/card/p-14

### P-15 — Know Who to Notify Before It Happens.

**When:** Working on know who to notify before it happens. (Privacy)

**Rule:** **Breach plan before you need one.** Know who you'd notify, in what order, within what timeframe. Figuring it out during an incident is too late.

**Reference:** https://launchyourvibe.live/card/p-15

### S-01 — Filter by User ID. Always.

**When:** Handling authentication, login, or session management

**Rule:** **Every user-specific fetch must filter by the authenticated user's ID.** Test it by logging in as User A and manually requesting User B's data. If you can see it, you have a problem. This isn't a platform feature you toggle on — it's a check you write and verify.

**Reference:** https://launchyourvibe.live/card/s-01

### S-02 — Use Supabase, Clerk, or Auth0.

**When:** Storing secrets, API keys, or credentials in code or config

**Rule:** **Rolling your own session management is where breaches are born.** Use Supabase Auth, Clerk, or Auth0. They handle tokens, refresh, MFA, and OAuth so you don't have to — and they stay patched when new vulnerabilities emerge.

**Reference:** https://launchyourvibe.live/card/s-02

### S-03 — Hiding a Button Is Not Security.

**When:** Protecting routes, APIs, admin actions, or sensitive data

**Rule:** **Every protected action checks the session on the server before returning data.** UI-only access control is theater — a crafted request bypasses it in seconds. Hiding a button is not access control.

**Reference:** https://launchyourvibe.live/card/s-03

### S-04 — Client Code Is Public Code.

**When:** Working on client code is public code. (Security)

**Rule:** **Anything shipped to the client is public.** API keys, service role keys, admin flags — none of it belongs in frontend code. If it's in your bundle, assume everyone can read it.

**Reference:** https://launchyourvibe.live/card/s-04

### S-05 — .env in Gitignore. Rotate if Exposed.

**When:** Working on .env in gitignore. rotate if exposed. (Security)

**Rule:** **Committed secrets live in history forever even after deletion.** Gitignore .env and rotate anything that ever shipped. A deleted line in today's code doesn't erase yesterday's commit.

**Reference:** https://launchyourvibe.live/card/s-05

### S-06 — Parameterize Every Query.

**When:** Working on parameterize every query. (Security)

**Rule:** **Raw string concatenation in queries is how SQL injection happens.** Parameterized queries are non-negotiable — let the database engine separate data from instructions.

**Reference:** https://launchyourvibe.live/card/s-06

### S-07 — localStorage = Readable by Any Script.

**When:** Persisting auth tokens (JWT, session) in the browser

**Rule:** **JWTs stored in localStorage are readable by any script on the page.** httpOnly cookies are not. One XSS vulnerability with localStorage tokens = full account takeover.

**Reference:** https://launchyourvibe.live/card/s-07

### S-08 — Lock Out After 5–10 Failures.

**When:** Working on lock out after 5–10 failures. (Security)

**Rule:** **Unlimited login attempts are a brute force welcome mat.** Throttle or lock after 5–10 failures. Add exponential backoff and alert on suspicious patterns.

**Reference:** https://launchyourvibe.live/card/s-08

### S-09 — Never Trust the Client.

**When:** Working on never trust the client. (Security)

**Rule:** **Everything reaching the database is checked for type, length, and allowed values.** Client-side validation is UX convenience, not security — it can be bypassed with a single curl command.

**Reference:** https://launchyourvibe.live/card/s-09

### S-10 — User Content Is Untrusted HTML.

**When:** Rendering user-generated or untrusted HTML/content

**Rule:** **User-generated content rendered directly to the DOM is an XSS vector.** Escape or sanitize everything that came from a user before it touches the page.

**Reference:** https://launchyourvibe.live/card/s-10

### S-11 — Including Staging. No Exceptions.

**When:** Working on including staging. no exceptions. (Security)

**Rule:** **HTTPS everywhere, always — no exceptions, including staging.** Let's Encrypt makes this free. There is no excuse — credentials and tokens travel in plaintext without it.

**Reference:** https://launchyourvibe.live/card/s-11

### S-12 — Search for key, secret, token.

**When:** Working on search for key, secret, token. (Security)

**Rule:** **Search your codebase for key, secret, token, password before every deploy.** One command, five minutes, no surprises. Make it part of your ship checklist.

**Reference:** https://launchyourvibe.live/card/s-12

### S-13 — Old Commits Keep Secrets Forever.

**When:** Working on old commits keep secrets forever. (Security)

**Rule:** **Before going public, run a secret scanner on your commit history.** You'd be surprised what's buried in old commits — deleted files don't delete the history.

**Reference:** https://launchyourvibe.live/card/s-13

### S-14 — npm audit Before Launch.

**When:** Working on npm audit before launch. (Security)

**Rule:** **Run npm audit or equivalent before launch.** Known vulnerabilities in packages you didn't write are still your problem — transitive dependencies included.

**Reference:** https://launchyourvibe.live/card/s-14

### S-15 — Rotate First. Investigate Second.

**When:** Working on rotate first. investigate second. (Security)

**Rule:** **The moment you suspect exposure, rotate first, investigate second.** Stop the bleeding before you figure out the wound. A compromised key still works until you revoke it.

**Reference:** https://launchyourvibe.live/card/s-15

### T-01 — Fluid Type: rem + clamp()

**When:** Working on fluid type: rem + clamp() (Spacing & Typography)

**Rule:** **Px breakpoints snap; user settings get ignored.** Set type in rem and scale smoothly with clamp(): a minimum rem, a viewport-relative middle term, and a maximum rem. One formula replaces separate mobile and desktop charts.

**Reference:** https://launchyourvibe.live/card/t-01

### T-02 — The 8pt Grid: Spacing in rem

**When:** Setting spacing, margins, padding, or layout gaps

**Rule:** **Arbitrary spacing makes screens feel unsteady.** Snap component gaps and padding to rem (0.25rem steps on an 8pt grid). For page-level breathing room, use vw in clamp() so gutters grow with the viewport.

**Reference:** https://launchyourvibe.live/card/t-02

### T-03 — Line Length: 45–75 Characters

**When:** Working on line length: 45–75 characters (Spacing & Typography)

**Rule:** **Long lines force the eye to hunt for the next line.** Short columns increase jumps per paragraph. 45–75 chars is where reading becomes effortless.

**Reference:** https://launchyourvibe.live/card/t-03

### T-04 — Weight Does the Hierarchy Work

**When:** Working on weight does the hierarchy work (Spacing & Typography)

**Rule:** **Color and size aren't the only tools.** Weight creates hierarchy even in a single color. Use 400 for body, 600 for labels, 700 for headings: avoid everything in between.

**Reference:** https://launchyourvibe.live/card/t-04

### T-05 — Line Height by Text Role

**When:** Working on line height by text role (Spacing & Typography)

**Rule:** **Tight headings look intentional. Tight body text looks like a bug.** Body line-height starts at 1.5 (WCAG). Button height comes from padding, not cramping line-height to 1.0.

**Reference:** https://launchyourvibe.live/card/t-05

### T-06 — Padding vs Margin: Inside vs Outside

**When:** Deciding between padding and margin on components

**Rule:** **Padding changes the element's feel; margin changes its relationship to neighbors.** Use padding to make a button feel spacious. Use margin to create breathing room in a layout.

**Reference:** https://launchyourvibe.live/card/t-06

### T-07 — Visual Hierarchy: 3 Levels Maximum

**When:** Working on visual hierarchy: 3 levels maximum (Spacing & Typography)

**Rule:** **Every level you add competes with the others.** Primary, secondary, and body. That's the hierarchy. Adding a fourth level usually means the third was doing too much.

**Reference:** https://launchyourvibe.live/card/t-07

### T-08 — Whitespace Is a Design Element

**When:** Working on whitespace is a design element (Spacing & Typography)

**Rule:** **Space is not empty: it's structure.** Generous spacing reduces cognitive load. The gaps between elements tell users which things belong together and what's a separate thought.

**Reference:** https://launchyourvibe.live/card/t-08

### T-09 — Left-Align Body Text. Center Sparingly.

**When:** Working on left-align body text. center sparingly. (Spacing & Typography)

**Rule:** **Centered multi-line text is the hallmark of amateur design.** The ragged left edge forces the eye to hunt for the start of each new line. Left-align everything longer than a headline.

**Reference:** https://launchyourvibe.live/card/t-09

### T-10 — Two Font Families. That's the Budget.

**When:** Working on two font families. that's the budget. (Spacing & Typography)

**Rule:** **Example font families in clear roles feel like a system.** Bold and regular are the same family, not a second one. Mixing families without roles creates noise. Three or more feel like you couldn't decide.

**Reference:** https://launchyourvibe.live/card/t-10

### T-12 — Letter Spacing: Where It Helps

**When:** Working on letter spacing: where it helps (Spacing & Typography)

**Rule:** **Tight letter spacing on big type is a design move. Tight spacing on small type is illegible.** The smaller the text, the more spacing it needs: not less. Never tighten body text.

**Reference:** https://launchyourvibe.live/card/t-12

### T-13 — Proximity Creates Visual Grouping

**When:** Working on proximity creates visual grouping (Spacing & Typography)

**Rule:** **A label 8px from its field looks owned. A label 16px away looks like a heading.** The gap between things signals their relationship: closer means "these belong together."

**Reference:** https://launchyourvibe.live/card/t-13

### T-14 — Safe Zones: Respect the Hardware

**When:** Building mobile layouts or full-bleed UI near device edges

**Rule:** **UI placed in the notch or behind the home indicator isn't just ugly: it's unusable.** Use CSS env() safe-area variables so your layout always respects the device's hardware edges.

**Reference:** https://launchyourvibe.live/card/t-14

### T-15 — Color + Type: Two Signals Are Enough

**When:** Working on color + type: two signals are enough (Spacing & Typography)

**Rule:** **Color alone fails for colorblind users.** Pair every color-coded state with a second signal: an icon, label, or shape. This isn't accessibility extra credit; it's baseline UX.

**Reference:** https://launchyourvibe.live/card/t-15
